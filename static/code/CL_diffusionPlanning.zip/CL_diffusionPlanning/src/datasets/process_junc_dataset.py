"""
GTA-IM Dataset
"""

import argparse
import os
import sys

import h5py
import numpy as np
import torch
import yaml

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../'))
sys.path.append(ROOT_DIR)


# from src.utils.pcd_utils import draw_frame


def prepare_dataset(seq_file, cfg, data_dir='GTA-IM-Dataset-processed'):
    """
    This function prepared the dataset for the human motion forecasting task.
    Specifically, it pre-processes the GTA-IM dataset.
    seq_file: str, the sequence file name e.g., '2020-06-09-16-09-56'
    cfg: str, the configuration file name e.g., 'gta.yml'
    data_dir: str, the directory to save the processed data, e.g., 'GTA-IM-Dataset-processed'
    """

    # Setup the configuration and parameters.
    cfg_name = os.path.join(ROOT_DIR, 'src/cfg/data/%s' % cfg)
    cfg = yaml.safe_load(open(cfg_name, 'r'))

    # Sequence parameters.
    n_hist, n_pred = cfg['n_hist'], cfg['n_pred']
    n_total = n_hist + n_pred
    nf_sq = cfg['nf_sq']
    n_joints = cfg['n_joints']

    # Spatial parameters.
    d = cfg['d_max']
    ms = cfg['map_size']  # map size
    vs = 2 * d / ms  # voxel size

    # Human pose parameters.
    save_dir = os.path.join(ROOT_DIR, 'data', data_dir)
    os.makedirs(save_dir, exist_ok=True)

    # ---------------------------------------------------

    # Plan the frame indexes.
    seq_len = 1000
    idxs_frame = np.arange(0, seq_len - n_total + 1, 1)

    # Divide the sequence into multiple subsequences, each with at most nf_sq frames.
    idxs_frame_sqs = [idxs_frame[i:i + nf_sq] for i in range(0, len(idxs_frame), nf_sq)]

    for isq, fidxs_subseq in enumerate(idxs_frame_sqs):

        # Check if the processed data already exists.
        subseq_name = seq_file + f'_sq{isq:02d}.hdf5'
        save_path = os.path.join(ROOT_DIR, f"data/{data_dir}/{subseq_name}")
        if not args.reset and os.path.exists(save_path):
            print(f"Skip {save_path} as the processed data already exists.")
            continue

        # ---------------------------------------------------
        # Address human poses and representation.
        joints_a = []  # joints in actor frame
        trajs_a = []  # trajectory in actor frame
        pose_a_mat_list = []  # pose transformation matrix
        traj_map_hist_list, traj_map_label_list = [], []  # 2D trajectory maps.

        print("Start addressing human poses and representation.")
        # Random pick a turning point and turn left or right (90 deg always).
        ss = 0.2  # step size
        x_turn = np.random.uniform(1, n_hist * ss, len(fidxs_subseq))  # N x 1
        trajs_raw_x = np.arange(-n_hist * ss, n_pred * ss, ss)  # (T * 2)
        trajs_raw = np.stack([trajs_raw_x, np.zeros_like(trajs_raw_x)], axis=-1)  # (T x 2) x 2
        trajs_raw = np.repeat(trajs_raw[None, :, :], len(fidxs_subseq), axis=0)  # N x T x 2
        trajs = trajs_raw.copy()  # Copy the trajectory for turning.
        # When it exceeds the turning point, turn left or right.
        for i in range(len(fidxs_subseq)):
            x, traj = x_turn[i], trajs_raw[i]
            idx_turn = np.where(traj[:, 0] > x)[0]
            trajs[i, idx_turn, 0] = np.ones_like(traj[idx_turn, 0]) * x
            trajs[i, idx_turn, 1] = (traj - x)[idx_turn, 0]

        if args.bimodal:
            # Flip the trajectory to augment and make it bimodal. Comment out for testing.
            # Randomly choose the index to flip.
            trajs_idx = np.random.choice(len(fidxs_subseq), (len(fidxs_subseq) // 2), replace=False)
            trajs[trajs_idx, n_hist:, 1] = -trajs[trajs_idx, n_hist:, 1]

        trajs_a = torch.from_numpy(trajs).float()  # (n_frames, n_total, 2)
        # trajs_a = torch.stack(trajs_a, dim=0).numpy()

        # Create the joints in actor frame.
        joints_a = torch.repeat_interleave(trajs_a[:, :, None, :], n_joints, dim=2)
        joints_a = torch.cat([joints_a, torch.zeros_like(joints_a[:, :, :, 0:1])], dim=-1)

        # ---------------------------------------------------
        # Create dummy pose_a_mat_list
        pose_a_mat_list = torch.eye(4).repeat(len(fidxs_subseq), 1, 1)

        # pose_a_mat_list = torch.stack(pose_a_mat_list, dim=0).numpy()
        # traj_map_hist_list = torch.stack(traj_map_hist_list, dim=0).numpy()
        # traj_map_label_list = torch.stack(traj_map_label_list, dim=0).numpy()

        # ---------------------------------------------------
        # Address surrounding point cloud.
        # Skip this step for not using the point cloud.

        # ---------------------------------------------------
        # Address occupancy map.
        print("Start addressing occupancy map.")
        occ_map_list = torch.ones((len(fidxs_subseq), 1, ms, ms, 1))
        # Create a path by setting pixels to zero (free),
        # Where there is a vertical hallway centering at the turning point.
        # The width of the hallway is 5 x step_size.
        # An example is visualized as below (turning point at (5, 6)):
        # 1 1 1 1 1 0 0 0 1 1
        # 1 1 1 1 1 0 0 0 1 1
        # 1 1 1 1 1 0 0 0 1 1
        # 0 0 0 0 0 0 0 0 1 1
        # 0 0 0 0 0 0 0 0 1 1
        # 0 0 0 0 0 0 0 0 1 1
        # 1 1 1 1 1 0 0 0 1 1
        # 1 1 1 1 1 0 0 0 1 1
        # 1 1 1 1 1 0 0 0 1 1
        w_pxl = 10 * ss / vs  # Corridor width in pixels
        x_turn_pxl = (x_turn + d) / vs
        y_turn_pxl = np.ones_like(x_turn_pxl) * (ms // 2)
        offset = np.random.uniform(-4 * ss / vs, 4 * ss / vs, len(fidxs_subseq))
        left, right = (x_turn_pxl - w_pxl // 2 + offset).astype('int'), (x_turn_pxl + w_pxl // 2 + offset).astype('int')
        up, bottom = (y_turn_pxl + w_pxl // 2).astype('int'), (y_turn_pxl - w_pxl // 2).astype('int')
        for i in range(len(fidxs_subseq)):
            occ_map_list[i, :, :, left[i]:right[i], :] = 0
            occ_map_list[i, :, bottom[i]:up[i], :left[i], :] = 0

        # # --------------------------------------------------------------
        # # Visualize the occupancy map. Test only.
        # # Uncomment this part for visualization.
        # import matplotlib.pyplot as plt
        # plt.imshow(occ_map_list[0, 0, :, :, 0].cpu().numpy())
        # plt.show()
        # # --------------------------------------------------------------

        # Save the processed data.
        data_dict = {
            'joints_a': joints_a,  # Joints in actor frame.
            'trajs_a': trajs_a,  # Trajectory in actor frame.
            'pose_a_mat_list': pose_a_mat_list,  # Pose transformation matrix.
            # 'traj_map_hist': traj_map_hist_list,  # 2D trajectory map (history).
            # 'traj_map_label': traj_map_label_list,  # 2D trajectory map (label).
            'occ_map_list': occ_map_list,  # Occupancy map.
        }
        f = h5py.File(save_path, 'w')
        for k, v in data_dict.items():
            f.create_dataset(k, data=v)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument('-c', '--cfg', default='junc.yml')
    parser.add_argument('-data_dir', type=str, default='Junc-Dataset-processed')
    parser.add_argument('--reset', action='store_true', default=True,
                        help='Reset the dataset, clean up the processed data.')
    parser.add_argument('--bimodal', action='store_true', default=False, )

    args = parser.parse_args()

    output_dir = os.path.join(ROOT_DIR, 'data', args.data_dir)
    if args.reset and os.path.exists(output_dir):
        os.system(f"rm -r {output_dir}")

    for i_seq in range(20):
        file = f'seq_{i_seq:02d}'
        print("Start working on ", file)
        prepare_dataset(file, args.cfg, args.data_dir)
