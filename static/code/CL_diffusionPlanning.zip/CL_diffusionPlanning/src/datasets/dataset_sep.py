import os
import re
import sys
from os.path import join

import h5py
import numpy as np
import torch
import yaml

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '../..'))
sys.path.append(ROOT_DIR)


def mix_data(args):
    # Load config.
    cfg_data_name = join(ROOT_DIR, 'src/cfg/data/%s' % args.cfg_data)
    cfg_data = yaml.safe_load(open(cfg_data_name, 'r'))

    if cfg_data['dataset'] == 'gta':
        data_dir = os.path.join(ROOT_DIR, 'data', 'GTA-IM-Dataset-processed')
    elif cfg_data['dataset'] == 'real_im':
        data_dir = os.path.join(ROOT_DIR, 'data', 'Real-IM-Dataset-processed')
    elif cfg_data['dataset'] == 'hps':
        data_dir = os.path.join(ROOT_DIR, 'data', 'HPS-Dataset-processed')
    elif cfg_data['dataset'] == 'dummy':
        data_dir = os.path.join(ROOT_DIR, 'data', 'Dummy-Dataset-processed')
    elif cfg_data['dataset'] == 'dummy_bi':
        data_dir = os.path.join(ROOT_DIR, 'data', 'Dummy-Bi-Dataset-processed')
    elif cfg_data['dataset'] == 'junc':
        data_dir = os.path.join(ROOT_DIR, 'data', 'Junc-Dataset-processed')
    else:
        raise ValueError(f'[Dataset] Invalid dataset {cfg_data["dataset"]}')

    files = [f for f in os.listdir(data_dir) if f.endswith('.hdf5')]
    idx2file = []
    fidx = []

    for file_idx, file in enumerate(files):
        seq_name = re.sub(r'_sq\d+\.hdf5$', '', file)
        data = h5py.File(f'{data_dir}/{file}', 'r')
        trajs_a = data['trajs_a']
        nf = trajs_a.shape[0]
        idx2file = idx2file + [file, ] * nf
        fidx = fidx + list(range(nf))

    print(f'[Data] Loaded {len(fidx)} files.')

    # Now we randomly divide the data into two parts, training and testing.
    # We same their sequence name and frame index for later use.
    n_data = len(fidx)
    n_train = int(n_data * 0.8)
    n_test = n_data - n_train
    idx = np.random.permutation(n_data)
    idx_train = idx[:n_train]
    idx_test = idx[n_train:]

    # Save the training and testing data.
    data_train = {}
    data_test = {}
    for i in idx_train:
        file = idx2file[i]
        if file not in data_train:
            data_train[file] = [fidx[i], ]
        else:
            data_train[file] = data_train[file] + [fidx[i], ]
    for i in idx_test:
        file = idx2file[i]
        if file not in data_test:
            data_test[file] = [fidx[i], ]
        else:
            data_test[file] = data_test[file] + [fidx[i], ]

    # Before saving the data, we need to sort the frame indices, also the file names as the keys.
    for file in data_train:
        data_train[file] = sorted(data_train[file])
    for file in data_test:
        data_test[file] = sorted(data_test[file])
    data_train_sorted = {k: sorted(data_train[k]) for k in sorted(data_train)}
    data_test_sorted = {k: sorted(data_test[k]) for k in sorted(data_test)}
    data_train = data_train_sorted
    data_test = data_test_sorted

    # Save the data separation into the yaml file.
    yaml.dump(data_train, open(f'{data_dir}/train.yml', 'w'))
    yaml.dump(data_test, open(f'{data_dir}/test.yml', 'w'))


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--cfg_data', default='junc.yml')
    parser.add_argument('--seed', default=0, type=int, help='seed')
    args = parser.parse_args()

    # print the configuration.
    print(f'[Data] Separate dataset with args: ')
    for arg in vars(args):
        print(f'[Train] {arg}: {getattr(args, arg)}')

    # Set seed.
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    mix_data(args)
