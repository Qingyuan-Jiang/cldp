"""
HPS Dataset Processing Script
"""

import argparse
import os
import pickle
import sys
import warnings
from copy import deepcopy

import numpy as np
import open3d as o3d
import torch
import yaml
from tqdm import tqdm
import h5py

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../'))
sys.path.append(ROOT_DIR)

from src.utils.gta_utils import compute_heading_direction, traj2map
from src.utils.hps_utils import load_pc_from_zip
from src.utils.pcd_utils import pcd2occmap

# from src.utils.pcd_utils import draw_frame

SCENE_DICT = {
    'MPI_BIB_AB_SEND': (
        'SUB1_MPI_BIB_AB_exercises.pkl',
    ),
    'MPI_BIBLIO_EG': (
        'SUB1_MPI_BIB_EG_book.pkl',
        'SUB1_MPI_BIB_EG_computer_stairs.pkl',
        'SUB1_MPI_BIB_EG_long.pkl',
        'SUB1_MPI_BIB_EG_tour.pkl',
    ),
    'MPI_BIBLIO_OG': (
        'SUB7_MPI_BIB_OG_lecture.pkl',
        'SUB7_MPI_BIB_OG_long.pkl',
        'SUB7_MPI_BIB_OG_read_sofa.pkl',
        'SUB7_MPI_BIB_OG_read_stairs.pkl',
        'SUB7_MPI_BIB_OG_use_computer_go_around.pkl',
        'SUB7_MPI_BIB_OG_write_move.pkl',
    ),
    'MPI_BIBLIO_UG': (
        'SUB6_MPI_BIB_UG_computers.pkl',
        'SUB6_MPI_BIB_UG_long.pkl',
        'SUB6_MPI_BIB_UG_lying.pkl',
        'SUB6_MPI_BIB_UG_read_on_stairs.pkl',
    ),
    'MPI_EG': (
        'Double_SUB2_MPI_EG.pkl',
        'Double_SUB5_MPI_EG.pkl',
        'SUB2_MPI_EG-001.pkl',
        'SUB2_MPI_EG-002.pkl',
        'SUB2_MPI_EG-003.pkl',
        'SUB2_MPI_EG-004.pkl',
    ),
    'MPI_Etage6': (
        'SUB4_MPI_Etage6_dancing_and_exercise.pkl',
        'SUB4_MPI_Etage6_eval.pkl',
        'SUB4_MPI_Etage6_long.pkl',
        'SUB4_MPI_Etage6_lying_on_the_couch_and_floor.pkl',
        'SUB4_MPI_Etage6_making_and_drinking_coffee.pkl',
        'SUB4_MPI_Etage6-walking_drinking_rotunda.pkl',
        'SUB4_MPI_Etage6_working_standing.pkl',
    ),
    'MPI_GEB_AB_S': (
        'SUB5_MPI_GEB-002.pkl',
        'SUB5_MPI_GEB-003.pkl',
        'SUB5_MPI_GEB-005.pkl',
        'SUB5_MPI_GEB-006.pkl',
    ),
    'MPI_KINO': (
        'SUB3_MPI_KINO_lecture_multilevel.pkl',
        'SUB3_MPI_KINO_sitting_multilevel.pkl',
        'SUB3_MPI_KINO_sitting_piano_multilevel.pkl',
    ),
}


def prepare_dataset(seq_file, cfg, data_dir='HPS-Dataset-processed'):
    """
    This function prepares the dataset for the human pose forecasting task.
    Specifically, it addresses the 'HPS-Dataset'.
    seq_file: str, the sequence file name e.g., 'SUB1_MPI_BIB_AB_exercises.pkl'
    cfg: str, the configuration file name e.g., 'hps.yml'
    data_dir: str, the directory to save the processed data, e.g., 'HPS-Dataset-processed'.
    """

    # Setup the configuration and parameters.
    cfg_name = os.path.join(ROOT_DIR, 'src/cfg/data/%s' % cfg)
    cfg = yaml.safe_load(open(cfg_name, 'r'))

    # Sequence parameters.
    n_hist, n_pred = cfg['n_hist'], cfg['n_pred']
    n_total = n_hist + n_pred
    step = cfg['step']
    sample_freq = cfg['sample_freq']
    nf_sq = cfg['nf_sq']

    # Spatial parameters.
    d = cfg['d_max']
    map_size = cfg['map_size']
    voxel_size = d / map_size
    z_min, z_max = cfg['z_min'], cfg['z_max']
    z_floor = cfg['z_floor']

    save_dir = os.path.join(ROOT_DIR, 'data', data_dir)
    os.makedirs(save_dir, exist_ok=True)

    # Load the sequence information.
    seq_path = os.path.join(ROOT_DIR, 'data/HPS-Dataset/hps_smpl', seq_file)
    with open(seq_path, 'rb') as f:
        info = pickle.load(f)

    # Find the corresponding scene.
    scene = None
    for k, v in SCENE_DICT.items():
        if seq_file in v:
            scene = k
            break
    if scene is None:
        warnings.warn(f"Scene not found for {seq_file}")

    scene_path = os.path.join(ROOT_DIR, 'data/HPS-Dataset/scenes', f'{scene}.zip')
    if not os.path.exists(scene_path):
        warnings.warn(f"Scene file missing: {scene_path}")
        return

    # ---------------------------------------------------
    joints = torch.from_numpy(info['poses']).float()  # SMPL joints. (n_frames, 72 (24 joints * 3))
    trajs = torch.from_numpy(info['transes']).float()  # 3D trajectory. (n_frames, 3)

    # Plan the frame indexes.
    seq_len = joints.shape[0]
    idxs_frame = np.arange(0, seq_len - n_total * step + 1, max(1, sample_freq))

    # Divide the sequence into multiple subsequences, each with at most nf_sq frames.
    idxs_frame_sqs = [idxs_frame[i:i + nf_sq] for i in range(0, len(idxs_frame), nf_sq)]

    # # Rollback to use only one subsequence.
    # idxs_frame_sqs = [idxs_frame]
    for isq, fidxs_subseq in enumerate(idxs_frame_sqs):

        # Check if the processed data already exists.
        subseq_name = seq_file.replace('.pkl', f'_sq{isq:02d}.hdf5')
        save_path = os.path.join(ROOT_DIR, f"data/{data_dir}/{subseq_name}")
        if not args.reset and os.path.exists(save_path):
            print(f"Skip {save_path} as the processed data already exists.")
            continue

        # ---------------------------------------------------
        # Address human poses and representation.
        joints_a = []  # joints in actor frame
        trajs_a = []  # trajectory in actor frame
        pose_a_mat_list = []  # pose transformation matrix
        traj_map_hist_list, traj_map_label_list = [], []  # 2D trajectory maps.

        print("Start addressing human poses and representation.")
        for fidx in tqdm(fidxs_subseq):
            pose = joints[fidx:fidx + n_total * step:step]
            traj = trajs[fidx:fidx + n_total * step:step]
            pos_curr = traj[n_hist - 1, :][None, :]
            pos_last = traj[n_hist - 2, :][None, :]
            pose_a_mat = compute_heading_direction(pos_curr, pos_last)
            pose_a_mat_list.append(pose_a_mat)

            R, t = pose_a_mat.inverse()[:3, :3], pose_a_mat.inverse()[:3, 3].unsqueeze(dim=0)

            # Transform the human trajectory to the actor's coordinate system.
            n_frames, ndim = traj.shape
            traj_a_flatten = traj.reshape(-1, 3)
            traj_a = (R @ traj_a_flatten.T + t.T).T.reshape(n_frames, -1)
            joints_a.append(pose)  # Save into joints in actor frame
            trajs_a.append(traj_a)

            device = torch.device('cpu')
            resol = 2 * d / map_size
            traj_hist = traj_a[:n_hist, :2]
            traj_label = traj_a[n_hist:, :2]
            traj_map_hist = traj2map(traj_hist.unsqueeze(0), d, resol,
                                     (1, n_hist, map_size, map_size, 1), device)[0]
            traj_map_label = traj2map(traj_label.unsqueeze(0), d, resol,
                                      (1, n_pred, map_size, map_size, 1), device, binary=True)[0]
            traj_map_hist_list.append(traj_map_hist)
            traj_map_label_list.append(traj_map_label)
        joints_a = torch.stack(joints_a, dim=0).numpy()
        trajs_a = torch.stack(trajs_a, dim=0).numpy()
        pose_a_mat_list = torch.stack(pose_a_mat_list, dim=0).numpy()
        traj_map_hist_list = torch.stack(traj_map_hist_list, dim=0).numpy()
        traj_map_label_list = torch.stack(traj_map_label_list, dim=0).numpy()

        # ---------------------------------------------------
        # Address surrounding point cloud.
        pcd_path = os.path.join(save_dir, seq_file.replace('.pkl', '.pcd'))
        if not args.reset and os.path.exists(pcd_path):
            print(f"Skip {pcd_path} as the point cloud already exists.")
            pcd_ds = o3d.io.read_point_cloud(pcd_path)
        else:
            print("Start addressing surrounding point cloud.")
            pcd_tri = load_pc_from_zip(scene_path, "*/pointcloud.ply")
            pcd = o3d.geometry.PointCloud()
            pcd.points = o3d.utility.Vector3dVector(np.array(pcd_tri.vertices))
            pcd.colors = o3d.utility.Vector3dVector(np.array(pcd_tri.visual.vertex_colors)[:, :3] / 255.)
            pcd_ds = deepcopy(pcd).voxel_down_sample(voxel_size=voxel_size / 2)  # Down-sample the point cloud.
            # o3d.visualization.draw_geometries([pcd_ds])  # Comment out for testing.

            # Save the point cloud for visualization and later use in open3d format.
            o3d.io.write_point_cloud(pcd_path, pcd_ds)

        # ---------------------------------------------------
        # Address occupancy map.
        occ_map_list = []
        print("Start addressing occupancy map.")
        for i in tqdm(range(len(fidxs_subseq))):
            pose_a_mat = pose_a_mat_list[i]
            x_a, y_a, z_a = pose_a_mat[:3, 3]
            # We first crop the point cloud roughly around the human.
            rough_bbox = o3d.geometry.AxisAlignedBoundingBox(min_bound=[-d * 2 + x_a, -d * 2 + y_a, z_a - d],
                                                             max_bound=[d * 2 + x_a, d * 2 + y_a, z_a + d])
            pcd_crop_raw = deepcopy(pcd_ds).crop(rough_bbox)
            pcd_a = pcd_crop_raw.transform(np.linalg.inv(pose_a_mat))
            floor_bbox = o3d.geometry.AxisAlignedBoundingBox(min_bound=[-d, -d, z_min], max_bound=[d, d, z_floor])
            env_bbox = o3d.geometry.AxisAlignedBoundingBox(min_bound=[-d, -d, z_floor], max_bound=[d, d, z_max])
            floor_pcd = deepcopy(pcd_a).crop(floor_bbox).voxel_down_sample(voxel_size=voxel_size)
            env_pcd = deepcopy(pcd_a).crop(env_bbox).voxel_down_sample(voxel_size=voxel_size)
            # o3d.visualization.draw_geometries([pcd_a, draw_frame()])
            # o3d.visualization.draw_geometries([floor_pcd, draw_frame()])
            # o3d.visualization.draw_geometries([env_pcd, draw_frame()])
            floor_map2d = pcd2occmap(floor_pcd, [-d, -d, z_min], [d, d, z_floor], voxel_size, map_size)
            env_map2d = pcd2occmap(env_pcd, [-d, -d, z_floor], [d, d, z_max], voxel_size, map_size)
            occ_map2d = np.ones((map_size, map_size)) * -1  # Define the full map as -1 (unknown).
            occ_map2d[floor_map2d > 0] = 0  # Define the floor as 0 (free).
            occ_map2d[env_map2d > 0] = 1  # Define the environment as 1 (occupied).
            # # Plot the occupancy map. Comment out for testing.
            # fig, ax = plt.subplots(1, 1)
            # ax.plot(trajs_a[fidx, :n_hist, 0], trajs_a[fidx, :n_hist, 1], 'b')
            # ax.plot(trajs_a[fidx, n_hist:, 0], trajs_a[fidx, n_hist:, 1], 'r')
            # ax.imshow(occ_map2d.squeeze(), cmap='gray', vmin=-1, vmax=1, alpha=0.5, extent=[-d, d, -d, d])
            # plt.show()
            occ_map_list.append(torch.from_numpy(occ_map2d).unsqueeze(0).unsqueeze(-1))

        occ_map_list = torch.stack(occ_map_list, dim=0).float().numpy()

        # Save the processed data.
        data_dict = {
            'joints': joints,  # Original SMPL joints.
            'joints_a': joints_a,  # Joints in actor frame.
            'trajs_a': trajs_a,  # Trajectory in actor frame.
            'pose_a_mat_list': pose_a_mat_list,  # Pose transformation matrix.
            'traj_map_hist': traj_map_hist_list,  # 2D trajectory map (history).
            'traj_map_label': traj_map_label_list,  # 2D trajectory map (label).
            'occ_map_list': occ_map_list,  # Occupancy map.
        }
        f = h5py.File(save_path, 'w')
        for k, v in data_dict.items():
            f.create_dataset(k, data=v)
        f.close()
        # np.save(save_path, data_dict)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument('-c', '--cfg', default='hps.yml')
    parser.add_argument('-data_dir', type=str, default='HPS-Dataset-processed')
    parser.add_argument('--reset', action='store_true',
                        help='Reset the dataset, clean up the processed data.')

    args = parser.parse_args()

    output_dir = os.path.join(ROOT_DIR, 'data', args.data_dir)
    if args.reset and os.path.exists(output_dir):
        os.system(f"rm -r {output_dir}")

    dataset_dir = os.path.join(ROOT_DIR, 'data/HPS-Dataset', 'hps_smpl')
    files = list(os.listdir(dataset_dir))
    files.sort()
    for file in files:
        print("Start working on ", file)
        prepare_dataset(file, args.cfg, args.data_dir)
