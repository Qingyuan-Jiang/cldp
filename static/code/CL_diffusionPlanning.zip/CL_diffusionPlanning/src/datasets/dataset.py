import os
import re
import sys

import h5py
import numpy as np
import torch
import yaml
from torch.utils.data import Dataset, DataLoader

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '../..'))
sys.path.append(ROOT_DIR)

from src.utils.gta_utils import rotate_map_by_angle


class HumanMotionDataset(Dataset):

    def __init__(self, cfg_data, cfg_model, mode):
        self.mode = mode
        self.n_hist, self.n_pred = cfg_data['n_hist'], cfg_data['n_pred']
        self.n_total = self.n_hist + self.n_pred
        self.n_joints = cfg_data['n_joints']
        self.step = cfg_data['step']

        self.d_max = cfg_data['d_max']

        self.use_raw_obs, self.use_env_pcd, self.use_map, self.use_traj_map = False, False, False, False
        self.use_pose_gt, self.use_traj_map_gt, self.use_env_pcd_vis = False, False, False
        self.map_size, self.voxel_size = None, None
        self.z_min, self.z_max = None, None  # The height range of the environment point cloud.
        self.num_scene_points = 2000  # Number of points in the environment point cloud.
        self.root_idx, self.left_hip_idx, self.right_hip_idx = None, None, None
        self.aug_data, self.aug_ang = False, 0

        # Set the configuration to the class attributes.
        for key, value in cfg_data.items():
            setattr(self, key, value)

        for key, value in cfg_model['input'].items():
            setattr(self, key, value)

        if cfg_data['dataset'] == 'gta':
            self.data_dir = os.path.join(ROOT_DIR, 'data', 'GTA-IM-Dataset-processed')
        elif cfg_data['dataset'] == 'real_im':
            self.data_dir = os.path.join(ROOT_DIR, 'data', 'Real-IM-Dataset-processed')
        elif cfg_data['dataset'] == 'hps':
            self.data_dir = os.path.join(ROOT_DIR, 'data', 'HPS-Dataset-processed')
        elif cfg_data['dataset'] == 'dummy':
            self.data_dir = os.path.join(ROOT_DIR, 'data', 'Dummy-Dataset-processed')
        elif cfg_data['dataset'] == 'dummy_bi':
            self.data_dir = os.path.join(ROOT_DIR, 'data', 'Dummy-Bi-Dataset-processed')
        elif cfg_data['dataset'] == 'junc':
            self.data_dir = os.path.join(ROOT_DIR, 'data', 'Junc-Dataset-processed')
        else:
            raise ValueError(f'[Dataset] Invalid dataset {cfg_data["dataset"]}')

        print('[Dataset] Read pre-processed data file')
        # Filter out point cloud saves.
        files = [f for f in os.listdir(self.data_dir) if f.endswith('.hdf5')]
        self.idx2file = []
        self.fidx = []  # Frame index inside each sequences.
        self.data = {}
        for file_idx, file in enumerate(files):
            seq_name = re.sub(r'_sq\d+\.hdf5$', '', file)
            if mode == 'train':
                if seq_name in cfg_data['test']:
                    # data = dict(np.load(f'{self.data_dir}/{file}', allow_pickle=True))
                    # Switch to h5py for faster data loading.
                    data = h5py.File(f'{self.data_dir}/{file}', 'r')
                    trajs_a = data['trajs_a']
                    nf = trajs_a.shape[0]
                    self.idx2file = self.idx2file + [file, ] * nf
                    self.fidx = self.fidx + list(range(nf))
                    self.data[file] = data
                else:
                    pass
            elif mode == 'test':
                if seq_name in cfg_data['test']:
                    pass
                else:
                    # data = dict(np.load(f'{self.data_dir}/{file}', allow_pickle=True))
                    # Switch to h5py for faster data loading.
                    data = h5py.File(f'{self.data_dir}/{file}', 'r')
                    trajs_a = data['trajs_a']
                    nf = trajs_a.shape[0]
                    self.idx2file = self.idx2file + [file, ] * nf
                    self.fidx = self.fidx + list(range(nf))
                    self.data[file] = data
            elif mode == 'train_mix':
                # In this mode, there is no selected sequence as the training/testing data.
                # Dataset separation is done and stored in the configuration file.
                train_datas = yaml.safe_load(open(os.path.join(self.data_dir, 'train.yml'), 'r'))
                if file in train_datas.keys():
                    data = h5py.File(f'{self.data_dir}/{file}', 'r')
                    nf = len(train_datas[file])
                    self.idx2file = self.idx2file + [file, ] * nf
                    self.fidx = self.fidx + train_datas[file]
                    self.data[file] = data
            elif mode == 'test_mix':
                test_datas = yaml.safe_load(open(os.path.join(self.data_dir, 'test.yml'), 'r'))
                if file in test_datas.keys():
                    data = h5py.File(f'{self.data_dir}/{file}', 'r')
                    nf = len(test_datas[file])
                    self.idx2file = self.idx2file + [file, ] * nf
                    self.fidx = self.fidx + test_datas[file]
                    self.data[file] = data
            else:
                raise ValueError(f'[Dataset] Invalid mode {mode}')

        print(f'[Dataset] Total number of frames: {len(self)}')
        print(f'[Dataset] Dataset initialization done.')

    def __len__(self):
        return len(self.fidx)

    def __getitem__(self, idx):

        file, fidx = self.idx2file[idx], self.fidx[idx]

        # Obtain human pose and human position (use spline4 with index 14 as representation).
        data = self.data[file]
        pose_a = torch.from_numpy(data['joints_a'][fidx])
        pose_hist = pose_a[:self.n_hist]
        pose_label = pose_a[self.n_hist:]
        pose_a_mat = torch.from_numpy(data['pose_a_mat_list'][fidx])

        # By default, add trajectory into the observation.
        traj_a_hist = torch.from_numpy(data['trajs_a'][fidx][:self.n_hist, :2])
        traj_a_label = torch.from_numpy(data['trajs_a'][fidx][self.n_hist:, :2])

        # Data augmentation. Randomly sample a rotation angle around the z-axis.
        angle = np.random.uniform(low=np.deg2rad(-self.aug_ang), high=np.deg2rad(self.aug_ang))
        if self.mode == 'train' and self.aug_data:
            rot_mat = np.eye(3)
            rot_mat[:2, :2] = np.array([[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]])
            rot_mat = torch.from_numpy(rot_mat).float()

            # Define rotation lambda for transformation rot_mat and pose.
            rot_lambda_pose = lambda x: (rot_mat @ x.reshape(-1, 3).T).T
            rot_lambda_traj = lambda x: (rot_mat[:2, :2] @ x.reshape(-1, 2).T).T

            # transform the pose to the rotated coordinate system.
            pose_hist_aug = rot_lambda_pose(pose_hist).reshape(self.n_hist, self.n_joints, 3)
            pose_label_aug = rot_lambda_pose(pose_label).reshape(self.n_pred, self.n_joints, 3)
            pose_a_mat_aug = pose_a_mat
            pose_a_mat_aug[:3, :3] = rot_mat @ pose_a_mat[:3, :3]
            pose_a_mat_aug[:3, 3] = rot_mat @ pose_a_mat[:3, 3]

            # Transform the trajectory to the rotated coordinate system.
            traj_a_hist_aug = rot_lambda_traj(traj_a_hist).reshape(self.n_hist, 2)
            traj_a_label_aug = rot_lambda_traj(traj_a_label).reshape(self.n_pred, 2)
        else:
            pose_hist_aug = pose_hist
            pose_label_aug = pose_label
            pose_a_mat_aug = pose_a_mat
            traj_a_hist_aug = traj_a_hist
            traj_a_label_aug = traj_a_label

        env_info = {'pose_a_mat': pose_a_mat_aug,
                    'meta': {'file': file, 'fidx': fidx, 'idx': idx}}
        pose_hist_info = {'pose': pose_hist_aug}
        pose_label_info = {'pose': pose_label_aug}
        pose_hist_info['traj'] = traj_a_hist_aug
        pose_label_info['traj'] = traj_a_label_aug

        # # Visualize the predicted poses with the environment point cloud.
        # # Comment out for testing.
        # from utils.vis_utils import vis_skeleton_pcd
        # from utils.pcd_utils import draw_frame
        # import open3d as o3d
        # line_set_hist = vis_skeleton_pcd(self.n_hist, self.n_joints, pose_hist.numpy(), color='r', dataset='GTA')
        # line_set_label = vis_skeleton_pcd(self.n_pred, self.n_joints, pose_label.numpy(), color='b', dataset='GTA')
        # points_full_np, colors_full_np = self.points[sub], self.colors[sub]
        # o3d.visualization.draw_geometries([line_set_hist, draw_frame()])
        # o3d.visualization.draw_geometries([line_set_hist, line_set_label, draw_frame()])

        if self.use_map:
            occ_map = data['occ_map_list'][fidx].squeeze()[None, ...]

            if self.mode == 'train' and self.aug_data:
                map_aug = rotate_map_by_angle(occ_map, angle)
            else:
                map_aug = occ_map
            env_info['map'] = torch.from_numpy(map_aug).unsqueeze(-1)

            # # Plot the occupancy map. Comment out for testing.
            # from src.utils.vis_utils import Visualizer
            # viser = Visualizer((-self.d_max, self.d_max, -self.d_max, self.d_max), 0.25, self.d_max, self.n_pred)
            # viser.vis_traj_with_occ("test_rot.png", traj_inp=traj_a_hist_aug, traj_gt=traj_a_label_aug, traj_ref_vis=None, occ_map=map_rot)
            # viser.vis_traj_with_occ("test_raw.png", traj_inp=traj_a_hist, traj_gt=traj_a_label, traj_ref_vis=None, occ_map=occ_map)

        if self.use_traj_map:
            traj_map_hist = data['traj_map_hist'][fidx].squeeze()
            traj_map_label = data['traj_map_label'][fidx].squeeze()

            if self.mode == 'train' and self.aug_data:
                traj_map_hist_aug = rotate_map_by_angle(traj_map_hist, angle)
                traj_map_label_aug = rotate_map_by_angle(traj_map_label, angle)
            else:
                traj_map_hist_aug = traj_map_hist
                traj_map_label_aug = traj_map_label
            pose_hist_info['traj_map'] = torch.from_numpy(traj_map_hist_aug).unsqueeze(-1)
            pose_label_info['traj_map'] = torch.from_numpy(traj_map_label_aug).unsqueeze(-1)

            # # Plot the occupancy map. Comment out for testing.
            # from src.utils.vis_utils import Visualizer
            # viser = Visualizer((-self.d_max, self.d_max, -self.d_max, self.d_max), 0.25, self.d_max, self.n_pred)
            # viser.vis_traj_with_occ("test_raw.png", traj_inp=traj_a_hist, traj_gt=traj_a_label, traj_ref_vis=None, occ_map=traj_map_label.sum(0))
            # viser.vis_traj_with_occ("test_rot.png", traj_inp=traj_a_hist_aug, traj_gt=traj_a_label_aug, traj_ref_vis=None, occ_map=traj_map_label_rot.sum(0))

        if self.use_pose_gt:
            pose_hist_info['pose_gt'] = pose_label_info['pose']
            pose_label_info['pose_gt'] = pose_label_info['pose']
            pose_hist_info['traj_gt'] = pose_label_info['traj']
            pose_label_info['traj_gt'] = pose_label_info['traj']

        if self.use_traj_map_gt:
            pose_hist_info['traj_map_gt'] = pose_label_info['traj_map']

        # if self.use_env_pcd:
        #     points_full_np, colors_full_np = self.points[sub], self.colors[sub]  # data_tmp['scene_points']
        #     if idx in self.scene_point_idx.keys():
        #         idx_cropped = self.scene_point_idx[idx]
        #     else:
        #         R, t = pose_a_mat.inverse()[:3, :3], pose_a_mat.inverse()[:3, 3].unsqueeze(dim=0)
        #         pos_a = pose_a_mat[:3, 3].unsqueeze(dim=0)
        #         # Filter out points that are too far away from the actor based on the bounding box.
        #         idx_coarse = crop_pcd_np(points_full_np, pos_a.numpy()[0], self.d_max * 2)
        #         points_coarse_np = points_full_np[idx_coarse]
        #
        #         points_coarse_a_np = (R @ points_coarse_np.T + t.T).T.numpy()
        #         idx_fine = crop_pcd_np(points_coarse_a_np, np.array([0, 0, 0]), self.d_max)
        #
        #         idx_cropped = idx_coarse[idx_fine]
        #         self.scene_point_idx[idx] = idx_coarse[idx_fine]
        #
        #         self.min_num_scene = len(idx_fine) if self.min_num_scene > len(idx_fine) else self.min_num_scene
        #         self.max_num_scene = len(idx_fine) if self.max_num_scene < len(idx_fine) else self.max_num_scene
        #         # print(f"[Dataset] Add frame {idx:d} to points point idxs")
        #         # print(f"[Dataset] num of points points from {self.min_num_scene:d} to {self.max_num_scene:d}")
        #
        #     # We need to sample a fixed number of points from it.
        #     n_pts = len(idx_cropped)
        #     if n_pts < self.num_scene_points:
        #         idx_sample = list(range(n_pts)) + np.random.choice(np.arange(n_pts),
        #                                                            self.num_scene_points - n_pts).tolist()
        #     else:
        #         idx_sample = np.random.choice(np.arange(n_pts), self.num_scene_points, replace=False)
        #     idx_smp = idx_cropped[idx_sample]
        #
        #     # Now we have environment point cloud around the actor.
        #     # We need to sample a fixed number of points from it.
        #     points_local, colors_local = points_full_np[idx_smp], colors_full_np[idx_smp]
        #     pcd_w_sampled = np2pcd_xyzrgb(np.hstack((points_local, colors_local)))
        #     # o3d.visualization.draw_geometries([pcd_w, draw_frame(origin=np.min(points_local, axis=0))])
        #
        #     # Transform the points point cloud to the actor's coordinate system.
        #     pcd_a = deepcopy(pcd_w_sampled).transform(pose_a_mat.inverse().numpy())
        #     # o3d.visualization.draw_geometries([pcd_a, draw_frame(scale=self.scale)])
        #     # o3d.visualization.draw_geometries([pcd_w_sampled, draw_frame(t, Rotation.from_matrix(R).as_quat())])
        #
        #     env_info['pcd.points'] = torch.from_numpy(np.asarray(pcd_a.points))
        #     env_info['pcd.colors'] = torch.from_numpy(np.asarray(pcd_a.colors))
        #
        # if self.use_env_pcd_vis:
        #     points_full_np, colors_full_np = self.points[sub], self.colors[sub]  # data_tmp['scene_points']
        #     if idx in self.scene_point_idx.keys():
        #         idx_cropped = self.scene_point_idx[idx]
        #     else:
        #         R, t = pose_a_mat.inverse()[:3, :3], pose_a_mat.inverse()[:3, 3].unsqueeze(dim=0)
        #         pos_a = pose_a_mat[:3, 3].unsqueeze(dim=0)
        #         # Filter out points that are too far away from the actor based on the bounding box.
        #         idx_coarse = crop_pcd_np(points_full_np, pos_a.numpy()[0], self.max_dist_from_human_vis * 4)
        #         points_coarse_np = points_full_np[idx_coarse]
        #
        #         points_coarse_a_np = (R @ points_coarse_np.T + t.T).T.numpy()
        #         idx_fine = crop_pcd_np(points_coarse_a_np, np.array([0, 0, 0]), self.max_dist_from_human_vis * 2)
        #
        #         idx_cropped = idx_coarse[idx_fine]
        #         self.scene_point_idx[idx] = idx_coarse[idx_fine]
        #
        #     # We need to sample a fixed number of points from it.
        #     n_pts = len(idx_cropped)
        #     if n_pts < self.num_scene_points_vis:
        #         idx_sample = list(range(n_pts)) + np.random.choice(np.arange(n_pts),
        #                                                            self.num_scene_points_vis - n_pts).tolist()
        #     else:
        #         idx_sample = np.random.choice(np.arange(n_pts), self.num_scene_points_vis, replace=False)
        #     idx_smp = idx_cropped[idx_sample]
        #
        #     # Now we have environment point cloud around the actor.
        #     # We need to sample a fixed number of points from it.
        #     points_local_vis, colors_local_vis = points_full_np[idx_smp], colors_full_np[idx_smp]
        #     pcd_w_vis = np2pcd_xyzrgb(np.hstack((points_local_vis, colors_local_vis)))
        #     # o3d.visualization.draw_geometries([pcd_w, draw_frame(origin=np.min(points_local, axis=0))])
        #
        #     # Transform the points point cloud to the actor's coordinate system.
        #     pcd_a_vis = deepcopy(pcd_w_vis).transform(pose_a_mat.inverse().numpy())
        #     # o3d.visualization.draw_geometries([pcd_a, draw_frame(scale=self.scale)])
        #     # o3d.visualization.draw_geometries([pcd_w_sampled, draw_frame(t, Rotation.from_matrix(R).as_quat())])
        #
        #     env_info['pcd_vis.points'] = torch.from_numpy(np.asarray(pcd_a_vis.points))
        #     env_info['pcd_vis.colors'] = torch.from_numpy(np.asarray(pcd_a_vis.colors))

        # if self.use_raw_obs:
        #     env_info['color'] = torch.from_numpy(np.asarray(self.rgb[sub][fidx:fidx + self.n_total]))
        #     env_info['depth'] = torch.from_numpy(np.asarray(self.depth[sub][fidx:fidx + self.n_total]))
        hist = {'env': env_info, 'pose': pose_hist_info}
        label = {'env': env_info, 'pose': pose_label_info}
        return hist, label


if __name__ == '__main__':
    cfg_data_name = os.path.abspath(os.path.join(os.path.dirname(__file__), '../cfg/data/%s' % 'junc.yml'))
    cfg_data = yaml.safe_load(open(cfg_data_name, 'r'))

    cfg_model_name = os.path.abspath(os.path.join(os.path.dirname(__file__), '../cfg/model/%s' % 'dif.yml'))
    cfg_model = yaml.safe_load(open(cfg_model_name, 'r'))

    seed = 0
    torch.manual_seed(seed)
    np.random.seed(seed)

    dataset = HumanMotionDataset(cfg_data, cfg_model, 'train_mix')
    dataloader = DataLoader(dataset, batch_size=8, shuffle=True, num_workers=0)
    hist, label = next(iter(dataloader))
    print(hist['pose']['traj'].shape)
