"""
GTA-IM Dataset
"""

import argparse
import os
import pickle
import sys
from copy import deepcopy

import cv2
import h5py
import numpy as np
import open3d as o3d
import torch
import yaml
from tqdm import tqdm

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../'))
sys.path.append(ROOT_DIR)

from src.utils.gta_utils import LIMBS, read_depthmap, compute_heading_direction, traj2map
from src.utils.pcd_utils import pcd2occmap


# from src.utils.pcd_utils import draw_frame


def create_skeleton_viz_data(nskeletons, njoints):
    lines = []
    colors = []
    for i in range(nskeletons):
        cur_lines = np.asarray(LIMBS)
        cur_lines += i * njoints
        lines.append(cur_lines)

        single_color = np.zeros([njoints, 3])
        single_color[:] = [0.0, float(i) / nskeletons, 1.0]
        colors.append(single_color[1:])

    lines = np.concatenate(lines, axis=0)
    colors = np.asarray(colors).reshape(-1, 3)
    return lines, colors


def prepare_dataset(seq_file, cfg, data_dir='GTA-IM-Dataset-processed'):
    """
    This function prepared the dataset for the human motion forecasting task.
    Specifically, it pre-processes the GTA-IM dataset.
    seq_file: str, the sequence file name e.g., '2020-06-09-16-09-56'
    cfg: str, the configuration file name e.g., 'gta.yml'
    data_dir: str, the directory to save the processed data, e.g., 'GTA-IM-Dataset-processed'
    """

    # Setup the configuration and parameters.
    cfg_name = os.path.join(ROOT_DIR, 'src/cfg/data/%s' % cfg)
    cfg = yaml.safe_load(open(cfg_name, 'r'))

    # Sequence parameters.
    n_hist, n_pred = cfg['n_hist'], cfg['n_pred']
    n_total = n_hist + n_pred
    step = cfg['step']
    nf_sq = cfg['nf_sq']

    # Spatial parameters.
    d = cfg['d_max']
    map_size = cfg['map_size']
    voxel_size = d / map_size
    z_min, z_max = cfg['z_min'], cfg['z_max']
    z_floor = cfg['z_floor']

    # Human pose parameters.
    root_idx = cfg['root_idx']

    save_dir = os.path.join(ROOT_DIR, 'data', data_dir)
    os.makedirs(save_dir, exist_ok=True)

    seq_dir = os.path.join(ROOT_DIR, 'data/GTA-IM-Dataset', seq_file)
    info = pickle.load(open(os.path.join(seq_dir, 'info_frames.pickle'), 'rb'))
    info_npz = np.load(os.path.join(seq_dir, 'info_frames.npz'))
    info_real = pickle.load(open(os.path.join(seq_dir, 'realtimeinfo.gz'), 'rb'))

    # ---------------------------------------------------
    room = info_real['setting']['room']  # Meta information.
    joints = torch.from_numpy(info_npz['joints_3d_world']).float()
    trajs = joints[:, root_idx, :]  # 3D trajectory. (n_frames, 3)

    # Plan the frame indexes.
    seq_len = joints.shape[0]
    idxs_frame = np.arange(0, seq_len - n_total + 1, step)

    # Divide the sequence into multiple subsequences, each with at most nf_sq frames.
    idxs_frame_sqs = [idxs_frame[i:i + nf_sq] for i in range(0, len(idxs_frame), nf_sq)]

    for isq, fidxs_subseq in enumerate(idxs_frame_sqs):

        # Check if the processed data already exists.
        subseq_name = seq_file + f'_sq{isq:02d}.hdf5'
        save_path = os.path.join(ROOT_DIR, f"data/{data_dir}/{subseq_name}")
        if not args.reset and os.path.exists(save_path):
            print(f"Skip {save_path} as the processed data already exists.")
            continue

        # ---------------------------------------------------
        # Address human poses and representation.
        joints_a = []  # joints in actor frame
        trajs_a = []  # trajectory in actor frame
        pose_a_mat_list = []  # pose transformation matrix
        traj_map_hist_list, traj_map_label_list = [], []  # 2D trajectory maps.

        print("Start addressing human poses and representation.")
        for fidx in tqdm(fidxs_subseq):
            pose = joints[fidx:fidx + n_total * step:step]
            traj = trajs[fidx:fidx + n_total * step:step]
            pos_curr = traj[n_hist - 1, :][None, :]
            pos_last = traj[n_hist - 2, :][None, :]
            pose_a_mat = compute_heading_direction(pos_curr, pos_last)
            pose_a_mat_list.append(pose_a_mat)

            R, t = pose_a_mat.inverse()[:3, :3], pose_a_mat.inverse()[:3, 3].unsqueeze(dim=0)

            # Transform the human pose to the actor's coordinate system.
            n_frames, n_joints, _ = pose.shape
            pose_a_flatten = pose.reshape(-1, 3)
            pose_a = (R @ pose_a_flatten.T + t.T).T.reshape(n_frames, n_joints, 3)
            traj_a_flatten = traj.reshape(-1, 3)
            traj_a = (R @ traj_a_flatten.T + t.T).T.reshape(n_frames, -1)
            joints_a.append(pose_a)  # Save into joints in actor frame
            trajs_a.append(traj_a)

            device = torch.device('cpu')
            resol = 2 * d / map_size
            traj_hist = traj_a[:n_hist, :2]
            traj_label = traj_a[n_hist:, :2]
            traj_map_hist = traj2map(traj_hist.unsqueeze(0), d, resol,
                                     (1, n_hist, map_size, map_size, 1), device)[0]
            traj_map_label = traj2map(traj_label.unsqueeze(0), d, resol,
                                      (1, n_pred, map_size, map_size, 1), device, binary=True)[0]
            traj_map_hist_list.append(traj_map_hist)
            traj_map_label_list.append(traj_map_label)
        joints_a = torch.stack(joints_a, dim=0).numpy()
        trajs_a = torch.stack(trajs_a, dim=0).numpy()
        pose_a_mat_list = torch.stack(pose_a_mat_list, dim=0).numpy()
        traj_map_hist_list = torch.stack(traj_map_hist_list, dim=0).numpy()
        traj_map_label_list = torch.stack(traj_map_label_list, dim=0).numpy()

        # ---------------------------------------------------
        # Address surrounding point cloud.
        # use nearby RGB-D frames to create the environment point cloud
        pcd_path = os.path.join(save_dir, f"{seq_file}.pcd")
        if not args.reset and os.path.exists(pcd_path):
            print(f"Skip {pcd_path} as the point cloud already exists.")
            pcd_ds = o3d.io.read_point_cloud(pcd_path)
        else:
            print("Start addressing surrounding point cloud.")
            pcd_ds = o3d.geometry.PointCloud()
            for i in tqdm(list(range(0, seq_len, 10))):
                f_depth = os.path.join(seq_dir, f'{i:05d}.png')
                if os.path.exists(f_depth):
                    infot = info[i]
                    cam_near_clip = infot['cam_near_clip']
                    if 'cam_far_clip' in infot.keys():
                        cam_far_clip = infot['cam_far_clip']
                    else:
                        cam_far_clip = 800.
                    depth = read_depthmap(f_depth, cam_near_clip, cam_far_clip)
                    # delete points that are more than 20 meters away
                    depth[depth > 20.0] = 0

                    # obtain the human mask
                    p = info_npz['joints_2d'][i, 0]
                    f_mask = os.path.join(seq_dir, f'{i:05d}_id.png')
                    id_map = cv2.imread(f_mask, cv2.IMREAD_ANYDEPTH)
                    human_id = id_map[
                        np.clip(int(p[1]), 0, 1079), np.clip(int(p[0]), 0, 1919)
                    ]

                    mask = id_map == human_id
                    kernel = np.ones((3, 3), np.uint8)
                    mask_dilation = cv2.dilate(
                        mask.astype(np.uint8), kernel, iterations=1
                    )
                    depth = depth * (1 - mask_dilation[..., None])
                    depth = o3d.geometry.Image(depth.astype(np.float32))
                    # cv2.imshow('tt', mask.astype(np.uint8)*255)
                    # cv2.waitKey(0)

                    f_color = os.path.join(seq_dir, f'{i:05d}.jpg')
                    color_raw = o3d.io.read_image(f_color)

                    focal_length = info_npz['intrinsics'][i, 0, 0]
                    rgbd_image = o3d.geometry.RGBDImage.create_from_color_and_depth(
                        color_raw,
                        depth,
                        depth_scale=1.0,
                        depth_trunc=15.0,
                        convert_rgb_to_intensity=False,
                    )
                    pcd = o3d.geometry.PointCloud.create_from_rgbd_image(
                        rgbd_image,
                        o3d.camera.PinholeCameraIntrinsic(
                            o3d.camera.PinholeCameraIntrinsic(
                                1920, 1080, focal_length, focal_length, 960.0, 540.0
                            )
                        ),
                    )
                    # o3d.visualization.draw_geometries([pcd, draw_frame()])
                    depth_pts = np.asarray(pcd.points)

                    depth_pts_aug = np.hstack(
                        [depth_pts, np.ones([depth_pts.shape[0], 1])]
                    )
                    cam_extr_ref = np.linalg.inv(info_npz['world2cam_trans'][i])
                    depth_pts = depth_pts_aug.dot(cam_extr_ref)[:, :3]
                    pcd.points = o3d.utility.Vector3dVector(depth_pts)
                    pcd_down = pcd.voxel_down_sample(voxel_size=voxel_size/4)
                    pcd_ds.points.extend(pcd_down.points)
                    pcd_ds.colors.extend(pcd_down.colors)
                    # if (i//10+1) % 20 == 0:
                    #     pcd_ds = o3d.geometry.voxel_down_sample(pcd_ds, voxel_size=0.005)
                    # if (i//10+1) % 100 == 0 and (i//10) < (len(list(range(splits[sp],splits[sp+1],10)))-100):
                    #     pcd_ds = o3d.geometry.voxel_down_sample(pcd_ds, voxel_size=0.01)

            pcd_ds = pcd_ds.voxel_down_sample(voxel_size=voxel_size/2)  # downsample the point cloud

            # Save the point cloud for visualization and later use in open3d format.
            o3d.io.write_point_cloud(pcd_path, pcd_ds)

        # ---------------------------------------------------
        # Address occupancy map.
        print("Start addressing occupancy map.")
        occ_map_list = []
        for i in tqdm(range(len(fidxs_subseq))):
            pose_a_mat = pose_a_mat_list[i]
            x_a, y_a, z_a = pose_a_mat[:3, 3]
            # We first crop the point cloud roughly around the human.
            rough_bbox = o3d.geometry.AxisAlignedBoundingBox(min_bound=[-d * 2 + x_a, -d * 2 + y_a, z_a - d],
                                                             max_bound=[d * 2 + x_a, d * 2 + y_a, z_a + d])
            pcd_crop_raw = deepcopy(pcd_ds).crop(rough_bbox)
            pcd_a = pcd_crop_raw.transform(np.linalg.inv(pose_a_mat))
            floor_bbox = o3d.geometry.AxisAlignedBoundingBox(min_bound=[-d, -d, z_min], max_bound=[d, d, z_floor])
            env_bbox = o3d.geometry.AxisAlignedBoundingBox(min_bound=[-d, -d, z_floor], max_bound=[d, d, z_max])
            floor_pcd = deepcopy(pcd_a).crop(floor_bbox).voxel_down_sample(voxel_size=voxel_size)
            env_pcd = deepcopy(pcd_a).crop(env_bbox).voxel_down_sample(voxel_size=voxel_size)
            # o3d.visualization.draw_geometries([floor_pcd, draw_frame()])
            # o3d.visualization.draw_geometries([env_pcd, draw_frame()])
            floor_map2d = pcd2occmap(floor_pcd, [-d, -d, z_min], [d, d, z_floor], voxel_size, map_size)
            env_map2d = pcd2occmap(env_pcd, [-d, -d, z_floor], [d, d, z_max], voxel_size, map_size)
            occ_map2d = np.ones((map_size, map_size)) * -1  # Define the full map as -1 (unknown).
            occ_map2d[floor_map2d > 0] = 0  # Define the floor as 0 (free).
            occ_map2d[env_map2d > 0] = 1  # Define the environment as 1 (occupied).
            # # Plot the occupancy map. Comment out for testing.
            # fig, ax = plt.subplots(1, 1)
            # ax.plot(pose_hist[:, root_idx, 0], pose_hist[:, root_idx, 1], 'r')
            # ax.plot(pose_label[:, root_idx, 0], pose_label[:, root_idx, 1], 'b')
            # ax.imshow(occ_map2d.squeeze(), cmap='gray', vmin=-1, vmax=1, alpha=0.5, extent=[-d, d, -d, d])
            # plt.show()
            occ_map_list.append(torch.from_numpy(occ_map2d).unsqueeze(0).unsqueeze(-1))

        occ_map_list = torch.stack(occ_map_list, dim=0).float().numpy()

        # Save the processed data.
        data_dict = {
            'meta': room,  # Meta information.
            'joints': joints,  # Original SMPL joints.
            'joints_a': joints_a,  # Joints in actor frame.
            'trajs_a': trajs_a,  # Trajectory in actor frame.
            'pose_a_mat_list': pose_a_mat_list,  # Pose transformation matrix.
            'traj_map_hist': traj_map_hist_list,  # 2D trajectory map (history).
            'traj_map_label': traj_map_label_list,  # 2D trajectory map (label).
            'occ_map_list': occ_map_list,  # Occupancy map.
        }
        f = h5py.File(save_path, 'w')
        for k, v in data_dict.items():
            f.create_dataset(k, data=v)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument('-c', '--cfg', default='gta.yml')
    parser.add_argument('-data_dir', type=str, default='GTA-IM-Dataset-processed')
    parser.add_argument('--reset', action='store_true',
                        help='Reset the dataset, clean up the processed data.')

    args = parser.parse_args()

    output_dir = os.path.join(ROOT_DIR, 'data', args.data_dir)
    if args.reset and os.path.exists(output_dir):
        os.system(f"rm -r {output_dir}")

    dataset_dir = os.path.join(ROOT_DIR, 'data/GTA-IM-Dataset/')
    files = os.listdir(dataset_dir)
    files.sort()
    for file in files:
        if '2020' not in file:
            continue
        if file.endswith(".zip"):
            continue
        print("Start working on ", file)
        prepare_dataset(file, args.cfg, args.data_dir)
