import torch

from src.diffusion.samp_ddpm import SamplerDDPM


class SamplerDDIM(SamplerDDPM):

    # sample quickly using DDIM
    @torch.no_grad()
    def p_sample(self, model, size, cond_inp, n=50):
        # x_T ~ N(0, 1), sample initial noise
        samples = torch.randn(size).to(self.dev)
        n_sample = samples.shape[0]

        # array to keep track of generated steps for plotting
        intermediate = []
        step_size = self.timesteps // n
        for i in range(self.timesteps, 0, -step_size):
            # print(f'[DDIM] sampling timestep {i:3d}', end='\r')

            # reshape time tensor
            t = torch.tensor([i / self.timesteps]).repeat(n_sample).to(self.dev)

            eps = model(samples, t, cond_inp)  # predict noise e_(x_t,t)
            samples = self.denoise_ddim(samples, i, i - step_size, eps)
            # intermediate.append(samples.detach().cpu().numpy())

        # intermediate = np.stack(intermediate)
        return samples, intermediate

    def denoise_ddim(self, x, t, t_prev, pred_noise):
        ab = self.ab_t[t]
        ab_prev = self.ab_t[t_prev]

        x0_pred = ab_prev.sqrt() / ab.sqrt() * (x - (1 - ab).sqrt() * pred_noise)
        dir_xt = (1 - ab_prev).sqrt() * pred_noise

        return x0_pred + dir_xt
