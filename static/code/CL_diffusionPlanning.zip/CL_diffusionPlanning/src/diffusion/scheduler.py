import torch


class Scheduler:

    def __init__(self, cfg_data, cfg_model):
        self.dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.timesteps = cfg_model['model_specs']['timesteps']
        self.beta_schedule = cfg_model['model_specs']['beta_schedule']
        self.beta1, self.beta2 = cfg_model['model_specs']['beta']

    def schedule_noise(self):
        raise NotImplementedError


class SchedulerLinear(Scheduler):

    def schedule_noise(self):
        return torch.linspace(self.beta1, self.beta2, self.timesteps + 1, device=self.dev).float()


class SchedulerCosine(Scheduler):

    def schedule_noise(self):
        s = 0.008  # 0.008 is the default value
        x = torch.linspace(0, self.timesteps, self.timesteps + 2, device=self.dev).float()
        ab_t = torch.cos(((x / self.timesteps) + s) / (1 + s) * torch.pi * 0.5) ** 2
        ab_t = ab_t / ab_t[0]
        betas = 1 - (ab_t[1:] / ab_t[:-1])
        betas = torch.clip(betas, 0, 0.999)
        return betas


class SchedulerLog(Scheduler):

    def schedule_noise(self):
        x = torch.linspace(0, self.timesteps, self.timesteps + 2, device=self.dev).float()
        ab_t = torch.log(x + 1) / torch.log(torch.tensor(self.timesteps + 1).float())
        betas = 1 - (ab_t[1:] / ab_t[:-1])
        betas = torch.clip(betas, 0, 0.999)
        return betas
