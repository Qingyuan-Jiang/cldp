import torch


def loss_traj_map_func(pred, label, cfg):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # loss_fn = torch.nn.KLDivLoss(reduction="batchmean").to(device)
    loss_fn = torch.nn.BCELoss(weight=torch.tensor(cfg['loss']['weight_bce'])).to(device)
    # loss_fn = torch.nn.BCELoss().to(device)
    traj_map_pred = pred['pose']['traj_map'].to(device)
    traj_map_label = label['pose']['traj_map'].to(device)
    loss_traj_map = loss_fn(traj_map_pred, traj_map_label)
    return loss_traj_map


def loss_collision_func(pred, label, cfg):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    traj_map_pred = pred['pose']['traj_map'].to(device)
    map = label['env']['map'].to(device)
    bs, nf, h, w, chn = traj_map_pred.shape
    map_ext = map.repeat(1, nf, 1, 1, 1)
    map_collision = torch.abs(map_ext)
    loss_collision = (map_collision * traj_map_pred).mean()
    return loss_collision


def loss_diffusion_noise_func(pred, label, cfg):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    noise_pred = pred['pose']['noise_pred'].to(device)
    noise_gt = pred['pose']['noise_gt']
    loss_f = torch.nn.MSELoss().to(device)
    loss = loss_f(noise_pred, noise_gt)
    return loss


def loss_kl_divergence_func(pred, label, cfg):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    mu = pred['pose']['mu'].to(device)
    logvar = pred['pose']['logvar'].to(device)
    loss_kld = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    return loss_kld


def loss_func(pred, label, cfg):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    loss_fn = torch.nn.MSELoss().to(device)

    # Loss components.
    use_pose = cfg['loss'].get('use_pose', False)
    use_traj = cfg['loss'].get('use_traj', False)
    use_final_pos = cfg['loss'].get('use_final_pos', False)
    use_traj_map = cfg['loss'].get('use_traj_map', False)
    use_collision = cfg['loss'].get('use_collision', False)
    use_diffusion = cfg['loss'].get('use_diffusion', False)
    use_kld = cfg['loss'].get('use_kld', False)

    loss = 0

    # Loss for skeleton poses for each frame.
    if use_pose:
        pred_pose, label_pose = pred['pose']['pose'].to(device), label['pose']['pose'].to(device)
        loss_pose = loss_fn(pred_pose, label_pose)
        loss = loss + loss_pose * cfg['loss']['weight_pose']

    # Loss of trajectory.
    if use_traj:
        traj_pred = pred['pose']['traj'].to(device)
        traj_label = label['pose']['traj'].to(device)
        loss_traj = loss_fn(traj_pred, traj_label) if use_traj else 0
        loss = loss + loss_traj * cfg['loss']['weight_traj']

    # Loss of position for the last frame.
    if use_final_pos:
        traj_pred = pred['pose']['traj'].to(device)
        traj_label = label['pose']['traj'].to(device)
        pos_pred, pos_label = traj_pred[:, -1, :2], traj_label[:, -1, :2]
        loss_pos = loss_fn(pos_pred, pos_label) if use_final_pos else 0
        loss = loss + loss_pos * cfg['loss']['weight_final_pos']

    # Loss of trajectory map.
    if use_traj_map:
        loss_traj_map = loss_traj_map_func(pred, label, cfg)
        loss = loss + loss_traj_map * cfg['loss']['weight_traj_map']

    # Loss of collision.
    if use_collision:
        loss_collision = loss_collision_func(pred, label, cfg)
        loss = loss + loss_collision * cfg['loss']['weight_collision']

    if use_diffusion:
        loss_diffusion_noise = loss_diffusion_noise_func(pred, label, cfg)
        loss = loss + loss_diffusion_noise * cfg['loss']['weight_diffusion']

    if use_kld:
        loss_kld = loss_kl_divergence_func(pred, label, cfg)
        loss = loss + loss_kld * cfg['loss']['weight_kld']

    return loss
