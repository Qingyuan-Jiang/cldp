import torch

from src.diffusion.scheduler import SchedulerLinear, SchedulerCosine, SchedulerLog

SchedulerCfg = {
    'linear': SchedulerLinear,
    'cosine': SchedulerCosine,
    'log': SchedulerLog,
}


class SamplerBase:

    def __init__(self, cfg_data, cfg_model):
        # Dataset parameters
        self.dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Diffusion process parameters
        self.timesteps = cfg_model['model_specs']['timesteps']
        self.beta_schedule = cfg_model['model_specs']['beta_schedule']
        self.scheduler = SchedulerCfg[self.beta_schedule](cfg_data, cfg_model)

        # construct DDPM noise schedule
        self.b_t = self.scheduler.schedule_noise()
        self.a_t = 1 - self.b_t
        self.ab_t = torch.cumsum(self.a_t.log(), dim=0).exp()  # a_bar_t = prod_{i=1}^t a_i
        self.ab_t[0] = 1

        # Further store the square root of the weight for the noise.
        self.sqrt_b_t = self.b_t.sqrt()
        self.sqrt_a_t = self.a_t.sqrt()
        self.sqrt_ab_t = self.ab_t.sqrt()
        self.sqrt_1mab_t = (1 - self.ab_t).sqrt()

    # helper function: perturbs a ground truth to a specified noise level
    def q_sample(self, x, t, noise):
        raise NotImplementedError

    def p_sample(self, model, size, cond_inp):
        raise NotImplementedError
