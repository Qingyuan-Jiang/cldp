import time

import torch

from src.diffusion.samp_base import SamplerBase


class SamplerDDPM(SamplerBase):

    def q_sample(self, x, t, noise):
        # From DeepLearning.AI example, they use the following formula:
        # Check out the link: https://learn.deeplearning.ai/courses/diffusion-models/lesson/5/training
        # return self.ab_t.sqrt()[t, None, None] * x + (1 - self.ab_t[t, None, None]) * noise

        # # However, the original formula uses the sqrt of the weight to the noise.
        # return self.ab_t.sqrt()[t, None, None] * x + self.sqrt_1mab_t[t, None, None] * noise

        # Note from Nov.1st, 2024:
        # The original formula does not perform well in the training,
        # causing the trajectory to be noise.
        # Leave this note here for future reference and research.

        # Temporarily use the formula from DeepLearning.AI example.
        # return self.sqrt_ab_t[t, None, None] * x + (1 - self.ab_t[t, None, None]) * noise

        # Still use the formula from the paper.
        return self.sqrt_ab_t[t, None, None] * x + self.sqrt_1mab_t[t, None, None] * noise

    # sample using standard algorithm
    @torch.no_grad()
    def p_sample(self, model, size, cond_inp):
        # x_T ~ N(0, 1), sample initial noise
        # samples = torch.randn(n_sample, 3, self.height, self.height).to(self.device)
        samples = torch.randn(size).to(self.dev)
        n_sample = samples.shape[0]

        # array to keep track of generated steps for plotting
        intermediate = []
        time_start = time.time()
        for i in range(self.timesteps, 0, -1):
            # print(f'[DDPM] sampling timestep {i:3d}', end='\r')

            # reshape time tensor
            t = torch.tensor([i / self.timesteps]).repeat(n_sample).to(self.dev)

            # sample some random noise to inject back in. For i = 1, don't add back in noise
            z = torch.randn_like(samples).to(self.dev) if i > 1 else 0

            eps = model(samples, t, cond_inp)  # predict noise e_(x_t,t, ctx)
            samples = self.denoise_add_noise(samples, i, eps, z)
            # if i % save_rate == 0 or i == self.timesteps or i < 8:
            #     intermediate.append(samples.detach().cpu().numpy())

        # intermediate = np.stack(intermediate)
        # print(f'[DDPM] Sampling completed in {time.time() - time_start} seconds.')
        return samples, intermediate

    def denoise_add_noise(self, x, t, pred_noise, z=None):
        # helper function; removes the predicted noise (but adds some noise back in to avoid collapse)
        if z is None:
            z = torch.randn_like(x)
        noise = self.sqrt_b_t[t] * z
        mean = (1 / self.sqrt_a_t[t]) * (x - pred_noise * ((1 - self.a_t[t]) / self.sqrt_1mab_t[t]))
        return mean + noise


class SampleDDPMPerturb(SamplerDDPM):

    def __init__(self, cfg_data, cfg_model):
        super(SampleDDPMPerturb, self).__init__(cfg_data, cfg_model)
        self.d_max = cfg_data['d_max']
        self.scale = 1.0
        self.clip_grad_by_value = {'min': -1, 'max': 1}

    def unnormalize(self, traj):
        return traj * self.d_max

    def p_sample(self, model, traj, map, save_rate=20):
        # x_T ~ N(0, 1), sample initial noise
        # samples = torch.randn(n_sample, 3, self.height, self.height).to(self.dev)
        samples = torch.randn_like(traj).to(self.dev)
        n_sample = samples.shape[0]

        # array to keep track of generated steps for plotting
        intermediate = []
        time_start = time.time()
        for i in range(self.timesteps, 0, -1):
            # print(f'[DDPM] sampling timestep {i:3d}', end='\r')

            # reshape time tensor
            t = torch.tensor([i / self.timesteps]).repeat(n_sample).to(self.dev)

            eps = model(samples, t, traj, map)  # predict noise e_(x_t,t, ctx)

            samples = (samples - eps * ((1 - self.a_t[i]) / (1 - self.ab_t[i]).sqrt())) / self.a_t[i].sqrt()

            with torch.enable_grad():
                x_in = samples.detach().requires_grad_(True)
                obj = self.optimize(x_in, map)
                grad = torch.autograd.grad(obj, x_in)[0]
                print("grad min and max", grad.min(), grad.max())
                ## clip gradient by value
                grad = torch.clip(grad, **self.clip_grad_by_value)

            # samples = self.denoise_add_noise(samples, i, eps, z)
            samples = samples - self.scale * grad * self.b_t[i]

            noise = torch.randn_like(samples) if i > 0 else 0.  # no noise if t == 0
            samples = samples + noise * self.sqrt_b_t[i]

            # samples = self.denoise_add_noise(samples, i, eps, z)
            # if i % save_rate == 0 or i == self.timesteps or i < 8:
            #     intermediate.append(samples.detach().cpu().numpy())

        # intermediate = np.stack(intermediate)
        # print(f'[DDPM] Sampling completed in {time.time() - time_start} seconds.')
        return samples, intermediate

    def optimize(self, x: torch.Tensor, map) -> torch.Tensor:
        """ Compute gradient for optimizer constraint
        Args:
            x: the denoised signal at current step, which is detached and is required grad
            data: data dict that provides original data

        Return:
            The optimizer objective value of current step
        """
        # # IMPORTANT: Unormalize the trajectory to be consistent with the map.
        x = self.unnormalize(x)

        loss_col = torch.tensor(0., device=self.dev).float()
        loss_length = torch.tensor(0., device=self.dev).float()
        loss_smooth = torch.tensor(0., device=self.dev).float()

        # # --------------------------------------------------------------
        # # Compute collision loss
        # # For each sample in the batch, compute the SDF for each point in the trajectory.
        # # for i in range(bs_real):
        # # x_s = x[i, :, :, :].mean(0)
        # # map_s = map[i, :, :, :].mean(0)
        # resol = 2 * self.d_max / self.map_size
        # bs, nf = x.shape[:2]
        #
        # # Compute signed distance function (SDF) for each point in the trajectory.
        # map_occ_idx = map > 0  # Extract non-zero values (occupied cells)
        #
        # # Pixels of the map
        # xx, yy = torch.meshgrid(torch.arange(self.map_size), torch.arange(self.map_size))
        # xx = xx.to(self.device)
        # yy = yy.to(self.device)
        # map_coord = torch.stack((xx, yy), dim=-1).float()
        # map_coord = map_coord.reshape(-1, 2)
        # map_coord_n = map_coord * resol - self.d_max
        #
        # # Get value of the map at the map coordinates.
        #
        # # Calculate distance and collision
        # for fidx in range(nf):
        #     traj_point = x[:, fidx, :].unsqueeze(1).repeat(1, self.map_size ** 2, 1)
        #     dist = torch.norm(map_coord_n - traj_point, dim=-1)
        #     collision = (dist < resol) & map_occ_idx.view(bs, -1)
        #     # collision = F.relu(resol - dist) * map_occ_idx.view(bs, -1).float()
        #     loss_col += collision.sum(dim=-1).float().sum()

        # --------------------------------------------------------------
        # Compute smoothness loss
        # Compute the first derivative (velocity)
        velocity = x[:, 1:, :] - x[:, :-1, :]
        # Compute the second derivative (acceleration)
        acceleration = velocity[:, 1:, :] - velocity[:, :-1, :]
        # Calculate the smoothness as the norm of the acceleration
        smoothness = torch.norm(acceleration, dim=-1)  # Shape: (batch_size, T-2)
        # Optionally, sum or average the smoothness over time
        smoothness_score = smoothness.mean(dim=1)  # Shape: (batch_size,)
        loss_smooth += smoothness_score.mean()

        # --------------------------------------------------------------
        # Compute the length loss
        # Compute the length of the trajectory
        # length = torch.norm(x[:, 1:, :] - x[:, :-1, :], dim=-1)
        length = torch.norm(x, dim=-1)
        # Optionally, sum or average the length over time
        length_score = length.mean(dim=1)
        loss_length += length_score.sum()

        lamb_smooth, lamb_col, lamb_length = 1., 0., 0.

        loss = (loss_smooth * lamb_smooth +
                loss_col * lamb_col +
                loss_length * lamb_length)
        print("Loss:", loss)
        return loss
