import os
import shutil
import sys
from os.path import abspath, dirname, join

import numpy as np
import torch
import torch.nn.functional as F
import yaml
from torch.utils.data import DataLoader

ROOT_DIR = abspath(join(dirname(__file__), '../../'))
sys.path.append(ROOT_DIR)

from src.datasets.dataset import HumanMotionDataset
from src.diffusion.loss import loss_func
from src.models.motion_pred import get_model


def train_one_epoch(net, dataloader, optimizer, loss_fn, cfg):
    loss_list = []

    for j, (poses_inp, poses_label) in enumerate(dataloader):
        optimizer.zero_grad()
        poses_outp = net.learn(poses_inp)

        loss = loss_fn(poses_outp, poses_label, cfg)

        loss.backward()
        optimizer.step()

        loss_list.append(loss.detach().cpu())
    return np.average(loss_list)


def test_model(net, testloader, loss_fn, cfg):
    loss_list = []
    net.eval()
    with torch.no_grad():
        for poses_inp, poses_label in testloader:
            poses_outp = net.inference(poses_inp)
            traj_pred = poses_outp['pose']['traj'].cpu().numpy()
            pose_label = poses_label['pose']['pose'].cpu().numpy()
            traj_label = poses_label['pose']['traj'].cpu().numpy()
            loss = F.mse_loss(torch.from_numpy(traj_pred), torch.from_numpy(traj_label))
            loss_list.append(loss.detach().cpu().numpy())
    net.train()
    return np.average(loss_list)


def main(args):
    # Load config.
    cfg_data_name = join(ROOT_DIR, 'src/cfg/data/%s' % args.cfg_data)
    cfg_data = yaml.safe_load(open(cfg_data_name, 'r'))
    data_name = cfg_data['dataset']

    cfg_model_name = join(ROOT_DIR, 'src/cfg/model/%s' % args.cfg_model)
    cfg_model = yaml.safe_load(open(cfg_model_name, 'r'))

    # Load conditioning config. Merge it into the model config.
    cfg_cond_name = join(ROOT_DIR, 'src/cfg/model/cond.yml')
    cfg_cond = yaml.safe_load(open(cfg_cond_name, 'r'))
    cfg_model.update(cfg_cond)

    model = cfg_model['model_name']
    name_specs = cfg_model['model_specs']['name_specs']
    model_name = model + '_' + name_specs

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    pose_predictor = get_model(cfg_data, cfg_model).to(dtype=torch.float32, device=device)

    epoch = args.epoch
    start_epoch = args.start_epoch
    save_freq = cfg_model['save_freq']
    test_freq = cfg_model['test_freq']
    batch_size = args.batch_size
    lr = float(cfg_model['lr']) if args.lr == 0 else args.lr
    lr_step_size = cfg_model['lr_step_size']
    lr_gamma = cfg_model['lr_gamma']
    num_workers = args.n_workers

    dataset = HumanMotionDataset(cfg_data, cfg_model, 'train')
    n_train_samp = int(0.95 * len(dataset))
    dataset_train, dataset_val = torch.utils.data.random_split(dataset, [n_train_samp, len(dataset) - n_train_samp])
    dataloader_train = DataLoader(dataset_train, batch_size=batch_size, shuffle=True, num_workers=num_workers)
    dataloader_val = DataLoader(dataset_val, batch_size=batch_size, shuffle=True, num_workers=num_workers)
    # dataloader_train = DataLoader(dataset_train, batch_size=batch_size, shuffle=True, num_workers=0)
    # dataloader_val = DataLoader(dataset_val, batch_size=batch_size, shuffle=True, num_workers=0)

    params = [p for p in pose_predictor.model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(params, lr=lr)

    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=lr_step_size, gamma=lr_gamma)

    exp_dir = f'results/{data_name}_{model_name}_{args.exp}/'
    weights_dir = join(ROOT_DIR, exp_dir, 'models/')
    os.makedirs(weights_dir, exist_ok=True)
    net_path_save = weights_dir + 'net_{:03d}.pt'.format(start_epoch)
    if start_epoch > 0 and os.path.exists(net_path_save):
        print(f'[Train] Loaded model from {net_path_save}')
        pose_predictor.load_model(net_path_save)
        print(f'[Train] Load model, number of params: {pose_predictor.num_of_params():.04f}M')
    else:
        print(f'[Train] Init. model, number of params: {pose_predictor.num_of_params():.04f}M')

    log_dir = join(ROOT_DIR, exp_dir, 'logs')
    os.makedirs(log_dir, exist_ok=True)
    shutil.copyfile(cfg_data_name, join(ROOT_DIR, exp_dir, args.cfg_data))
    shutil.copyfile(cfg_model_name, join(ROOT_DIR, exp_dir, args.cfg_model))
    shutil.copyfile(cfg_cond_name, join(ROOT_DIR, exp_dir, 'cond.yml'))

    for i in range(start_epoch, start_epoch + epoch):

        loss_train = train_one_epoch(pose_predictor, dataloader_train, optimizer, loss_func, cfg_model)
        print(f"[Train] Epoch {i:03d}. Avg. train loss {loss_train:.05f}")

        scheduler.step()

        if (i + 1) % save_freq == 0:
            net_path_save = weights_dir + 'net_{:03d}.pt'.format(i + 1)
            pose_predictor.save_model(net_path_save)

        if (i + 1) % test_freq == 0:
            loss_test = test_model(pose_predictor, dataloader_val, loss_func, cfg_model)
            print(f"[Train] Epoch {i:03d}. Avg. train loss {loss_train:.05f}. test loss {loss_test:.05f}")

    # writer.close()


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--cfg_data', default='junc.yml')
    parser.add_argument('--cfg_model', default='base.yml')
    parser.add_argument('--seed', default=0, type=int, help='seed')
    parser.add_argument('--start_epoch', default=0, type=int, help='manual epoch number (useful on restarts)')
    parser.add_argument('--epoch', default=20, type=int, help='number of total epochs to run')
    parser.add_argument('--batch_size', default=64, type=int, help='batch size')
    parser.add_argument('--n_workers', default=0, type=int, help='number of workers')
    parser.add_argument('--lr', default=0., type=float, help='initial learning rate')
    parser.add_argument('--exp', default='1204', type=str, help='experiment name')

    args = parser.parse_args()

    # print the configuration.
    print(f'[Train] Start training with args: ')
    for arg in vars(args):
        print(f'[Train] {arg}: {getattr(args, arg)}')

    # Set seed.
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    main(args)
