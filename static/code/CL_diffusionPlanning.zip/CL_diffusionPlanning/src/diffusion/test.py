import os
import pickle
import sys
from os.path import abspath, dirname, join

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader
from tqdm import tqdm

ROOT_DIR = abspath(join(dirname(__file__), '../../'))
sys.path.append(ROOT_DIR)

# from datasets.dataset_test import DatasetGTA
from src.datasets.dataset import HumanMotionDataset
from src.models.motion_pred import get_model
from src.utils.vis_utils import Visualizer


def cleanup(args):
    """
    In this function, we will clean up all the diffusion results.
    """
    # Load config.
    cfg_data_name = join(ROOT_DIR, 'src/cfg/data/%s' % args.cfg_data)
    cfg_data = yaml.safe_load(open(cfg_data_name, 'r'))
    data_name = cfg_data['dataset']

    cfg_model_name = join(ROOT_DIR, 'src/cfg/model/%s' % args.cfg_model)
    cfg_model = yaml.safe_load(open(cfg_model_name, 'r'))

    # Load conditioning config. Merge it into the model config.
    cfg_cond_name = join(ROOT_DIR, 'src/cfg/model/cond.yml')
    cfg_cond = yaml.safe_load(open(cfg_cond_name, 'r'))
    cfg_model.update(cfg_cond)

    model = cfg_model['model_name']
    name_specs = cfg_model['model_specs']['name_specs']
    model_name = model + '_' + name_specs

    exp_dir = os.path.join(ROOT_DIR, f'results/{data_name}_{model_name}_{args.exp}/')
    vis_dir = join(exp_dir, f'vis')
    type = args.sampler
    if not os.path.exists(vis_dir):
        return
    for folder in os.listdir(vis_dir):
        for f in os.listdir(join(vis_dir, folder)):
            if f.endswith(f'{type}.png'):
                os.remove(join(vis_dir, folder, f))


def inference(net, dataloader, exp_dir, arg):
    traj_inp_list, traj_pred_list, traj_gt_list = [], [], []
    maps_vis_list = []
    meta_list = []
    fnames, fidxs = [], []
    info_dict = {}
    net.eval()
    for (poses_inp, poses_label) in tqdm(dataloader):
        with torch.no_grad():
            n_sample = arg.n_sample
            poses_outp = net.inference(poses_inp, n_sample=n_sample, sampler=arg.sampler)

            traj_inp = poses_inp['pose']['traj'].cpu().numpy()
            traj_gt = poses_label['pose']['traj'].cpu().numpy()

            batch_size, n_pred, _ = traj_inp.shape
            traj_pred = poses_outp['pose']['traj'].cpu().numpy()

            # Store the trajectory inputs, predictions and ground truth.
            meta_list.append(poses_inp['env']['meta'])
            fnames += (poses_inp['env']['meta']['file'])
            fidxs += (poses_inp['env']['meta']['fidx'])
            traj_inp_list.append(traj_inp)
            traj_pred_list.append(traj_pred)
            traj_gt_list.append(traj_gt)

            # Prepare the map.
            maps_raw = poses_inp['env']['map'].cpu().numpy().squeeze()
            maps = np.repeat(maps_raw, n_sample, axis=0)
            maps_vis = maps.reshape((batch_size, n_sample, maps_raw.shape[1], maps_raw.shape[2]))
            maps_vis_list.append(maps_vis)

        # If we are testing for one batch, we can break the loop.
        if not arg.all:
            break

    traj_inp_list = np.concatenate(traj_inp_list, axis=0)
    traj_pred_list = np.concatenate(traj_pred_list, axis=0)
    traj_gt_list = np.concatenate(traj_gt_list, axis=0)
    maps_vis_list = np.concatenate(maps_vis_list, axis=0)

    res_dir = join(exp_dir, 'res')
    os.makedirs(res_dir, exist_ok=True)
    pickle_path = join(res_dir, 'results.pkl')
    info_dict['traj_inp'] = traj_inp_list
    info_dict['traj_pred'] = traj_pred_list
    info_dict['traj_gt'] = traj_gt_list
    info_dict['maps_vis'] = maps_vis_list
    info_dict['meta'] = {'file': fnames, 'fidx': fidxs}
    with open(pickle_path, 'wb') as f:
        pickle.dump(info_dict, f)
    return info_dict


def qualitative_eval(viser, exp_dir, cfg_model, arg):
    # Load the results from the pickle file.
    res_dir = join(exp_dir, 'res')
    os.makedirs(res_dir, exist_ok=True)
    pickle_path = join(res_dir, 'results.pkl')
    with open(pickle_path, 'rb') as f:
        info_dict = pickle.load(f)

    # meta_list = info_dict['meta']
    fnames = info_dict['meta']['file']
    fidxs = info_dict['meta']['fidx']
    traj_inp_list = info_dict['traj_inp']
    traj_pred_list = info_dict['traj_pred']
    traj_gt_list = info_dict['traj_gt']
    maps_vis_list = info_dict['maps_vis']

    # Visualize the trajectory inputs and predictions.
    # samples are bsx10x2. Draw them all in subplots.
    # Note that x, y should be at equal distance from the origin.

    vis_dir = join(exp_dir, f'vis/')
    n_sample = arg.n_sample
    n, n_pred, _ = traj_inp_list.shape
    traj_pred_list = traj_pred_list.reshape((n, n_sample, n_pred, 2))

    for k, (fname, fidx, traj_inp, traj_pred, traj_gt, maps_vis) in tqdm(enumerate(
            zip(fnames, fidxs, traj_inp_list, traj_pred_list, traj_gt_list, maps_vis_list)), mininterval=100):

        # batch_size, n_pred, _ = traj_inp.shape
        # traj_pred_vis = traj_pred.reshape((n_sample, n_pred, 2))

        # bs = traj_inp.shape[0]
        # for i in range(bs):
        seq_name = fname.split('.')[0]
        # Prepare the subfolder for the visualization.
        vis_subfolder = join(vis_dir, f'{seq_name}')
        os.makedirs(vis_subfolder, exist_ok=True)
        type = arg.sampler
        img_name = f'{int(fidx):04d}_{type}.png'
        img_path = join(vis_subfolder, img_name)
        viser.vis_traj_with_occ(fname=img_path, traj_inp=traj_inp, traj_gt=traj_gt,
                                traj_ref_vis=traj_pred, occ_map=maps_vis[0])

        # If we are testing for one batch, we can break the loop.
        if not arg.all and k >= arg.batch_size:
            break

    return


def quantitative_eval(exp_dir, cfg_model, arg):
    # Load the results from the pickle file.
    res_dir = join(exp_dir, 'res')
    os.makedirs(res_dir, exist_ok=True)
    pickle_path = join(res_dir, 'results.pkl')
    with open(pickle_path, 'rb') as f:
        info_dict = pickle.load(f)

    traj_inp_list = info_dict['traj_inp']
    traj_pred_list = info_dict['traj_pred']
    traj_gt_list = info_dict['traj_gt']

    n_sample = arg.n_sample

    ade_list = []
    fde_list = []
    k = 5  # Number of samples to consider for the average displacement error.
    # for i, (meta, traj_inp, traj_pred, traj_gt) in tqdm(enumerate(
    #         zip(meta_list, traj_inp_list, traj_pred_list, traj_gt_list))):
    n, n_pred, _ = traj_inp_list.shape  # n: number of test points.
    traj_gt_repeat = np.repeat(traj_gt_list, n_sample, axis=0)
    # Note: This is repeat from numpy, which performs different from torch.repeat.

    traj_pred_ = traj_pred_list.reshape((n, n_sample, n_pred, 2))
    traj_gt_repeat_ = traj_gt_repeat.reshape((n, n_sample, n_pred, 2))
    de = np.linalg.norm(traj_pred_ - traj_gt_repeat_, axis=-1)  # Displacement error: n x n_sample x n_pred
    ade = np.mean(de, axis=-1)  # n x n_sample
    ade_1 = np.min(ade, axis=-1)
    ade_k = np.mean(np.sort(ade, axis=-1)[:, :5], axis=-1)
    ade_n = np.mean(ade, axis=-1)  # n
    ade_list.append([ade_1, ade_k, ade_n])

    fde = de[:, :, -1]  # n x n_sample
    fde_1 = np.min(fde, axis=-1)
    fde_k = np.mean(np.sort(fde, axis=-1)[:, :k], axis=-1)
    fde_n = np.mean(fde, axis=-1)
    fde_list.append([fde_1, fde_k, fde_n])

    # print(f'Batch {k} ADE: {np.mean(ade_n)}, FDE: {np.mean(fde_n)}')
    #
    # # If we are testing for one batch, we can break the loop.
    # if not arg.all:
    #     break

    # Now we can calculate the average ADE and FDE.
    ade_list = np.stack(ade_list, axis=0)  # n x 3 (1, k, n)
    fde_list = np.stack(fde_list, axis=0)
    ade_1 = np.mean(ade_list[:, 0])
    ade_k = np.mean(ade_list[:, 1])
    ade_n = np.mean(ade_list[:, 2])
    fde_1 = np.mean(fde_list[:, 0])
    fde_k = np.mean(fde_list[:, 1])
    fde_n = np.mean(fde_list[:, 2])
    fde_var = np.var(fde_list[:, 2])

    # Save the results to a file.
    result_path = join(res_dir, 'results.txt')
    with open(result_path, 'w') as f:
        f.write(f'Results for {cfg_model["model_name"]}\n')
        f.write(f'k = {k}\n')
        f.write(f'1-minADE: {ade_1:.5f}, k-minADE: {ade_k:.5f}, minADE: {ade_n:.5f}\n')
        f.write(f'1-minFDE: {fde_1:.5f}, k-minFDE: {fde_k:.5f}, minFDE: {fde_n:.5f}\n')
        f.write(f'FDE variance: {fde_var:.5f}\n')

    # Print the results by cat.
    with open(result_path, 'r') as f:
        print(f.read())

    return


def test(args):
    # Load config.
    cfg_data_name = join(ROOT_DIR, 'src/cfg/data/%s' % args.cfg_data)
    cfg_data = yaml.safe_load(open(cfg_data_name, 'r'))
    data_name = cfg_data['dataset']

    cfg_model_name = join(ROOT_DIR, 'src/cfg/model/%s' % args.cfg_model)
    cfg_model = yaml.safe_load(open(cfg_model_name, 'r'))
    model = cfg_model['model_name']
    model_name = model + '_' + args.model_name

    exp_dir = os.path.join(ROOT_DIR, f'results/{data_name}_{model_name}_{args.exp}/')

    # Now load configuration from the experiment folder.
    cfg_data_name = join(exp_dir, args.cfg_data)
    cfg_data = yaml.safe_load(open(cfg_data_name, 'r'))

    cfg_model_name = join(exp_dir, args.cfg_model)
    cfg_model = yaml.safe_load(open(cfg_model_name, 'r'))

    # Load conditioning config. Merge it into the model config.
    cfg_cond_name = join(exp_dir, 'cond.yml')
    cfg_cond = yaml.safe_load(open(cfg_cond_name, 'r'))
    cfg_model.update(cfg_cond)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    pose_predictor = get_model(cfg_data, cfg_model).to(dtype=torch.float32, device=device)

    epoch = args.epoch
    batch_size = args.batch_size

    n_pred = cfg_data['n_pred']  # Number of predicted frames
    d_max = cfg_data['d_max']  # Maximum distance for visualization

    weights_dir = os.path.join(exp_dir, 'models')
    os.makedirs(weights_dir, exist_ok=True)
    net_path_save = join(weights_dir, 'net_{:03d}.pt'.format(epoch))
    pose_predictor.load_model(net_path_save)
    print(f'Loaded model from {net_path_save}')
    print(f'Number of parameters: {pose_predictor.num_of_params():.04f}M')

    # dataset_train = HumanMotionDataset(cfg_data, cfg_model, 'train')
    dataset_test = HumanMotionDataset(cfg_data, cfg_model, 'test')
    # n_train_samp = int(0.8 * len(dataset_train))
    # dataset_train, dataset_test = torch.utils.data.random_split(dataset_train, [n_train_samp, len(dataset_train) - n_train_samp])
    # dataloader_train = DataLoader(dataset_train, batch_size=batch_size, shuffle=True, num_workers=6)
    # dataloader_test = DataLoader(dataset_test, batch_size=batch_size, shuffle=True, num_workers=6)
    # dataloader_train = DataLoader(dataset_train, batch_size=batch_size, shuffle=True, num_workers=0)
    dataloader_test = DataLoader(dataset_test, batch_size=batch_size, shuffle=True, num_workers=0)

    viser = Visualizer((-d_max, d_max, -d_max, d_max), 0.25, d_max, n_pred)
    # test_dataset(pose_predictor, dataloader_train, viser, cfg_model, args)
    inference(pose_predictor, dataloader_test, exp_dir, args) if args.infer else None

    # Qualitative evaluation
    qualitative_eval(viser, exp_dir, cfg_model, args) if args.qual else None

    # Quantitative evaluation
    quantitative_eval(exp_dir, cfg_model, args) if args.quant else None


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--cfg_data', default='junc.yml')
    parser.add_argument('--cfg_model', default='base.yml')
    parser.add_argument('--model_name', default='tr', type=str, help='model name')
    parser.add_argument('--seed', default=0, type=int, help='random seed')
    parser.add_argument('--n_sample', default=10, type=int, help='number of samples for diffusion')
    parser.add_argument('--epoch', default=20, type=int, help='number of total epochs to run')
    parser.add_argument('--batch_size', default=64, type=int, help='batch size')
    parser.add_argument('--exp', default='1204', type=str, help='experiment name')
    parser.add_argument('--sampler', type=str, default='ddpm',
                        choices=['ddpm', 'ddim', 'perturb_ddpm'],
                        help='Choice of sampling methods \n'
                             'ddim: Differentiable diffusion model. \n'
                             'ddpm: Differentiable diffusion model with noise. \n'
                             'perturb_ddpm: Differentiable diffusion model with noise and perturbation. \n'
                        )

    parser.add_argument('--infer', action='store_true', default=False, help='Run the inference')
    parser.add_argument('--qual', action='store_true', default=False, help='Run the qualitative evaluation')
    parser.add_argument('--quant', action='store_true', default=False, help='Run the quantitative evaluation')

    parser.add_argument('--all', action='store_true', default=False, help='Run through all the test samples')
    parser.add_argument('--reset', action='store_true', default=False, help='Reset the visualization folder')

    args = parser.parse_args()

    # print the configuration.
    print("[Test] Evaluation with args: ")
    for arg in vars(args):
        print(f'[Test] {arg}: {getattr(args, arg)}')

    # setup random seed
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    cleanup(args) if args.reset else None
    test(args)
