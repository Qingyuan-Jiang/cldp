def rewrite_cfg_with_arg(cfg, args):
    # Automatically rewrite.

    cfg['algo'] = cfg['algo'] if args.algo == '' else args.algo
    cfg['env'] = cfg['env'] if args.env == '' else args.env

    return cfg

