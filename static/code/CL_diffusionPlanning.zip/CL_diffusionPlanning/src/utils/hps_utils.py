import fnmatch
import os
from io import BytesIO
from zipfile import ZipFile

import trimesh


def open_from_zip(zippath, datapath, return_zip_path=False):
    input_zip = ZipFile(zippath)
    match_fn = lambda x: fnmatch.fnmatch(x, datapath)
    filenames = list(filter(match_fn, input_zip.namelist()))
    if len(filenames) == 0:
        raise FileNotFoundError("No file matching '{}' in archive".format(datapath))
    elif len(filenames) > 1:
        raise FileNotFoundError("More than one file matching '{}' exists in archive: {}".format(datapath, filenames))
    else:
        filename = filenames[0]
        filehandler = BytesIO(input_zip.read(filename))
        if return_zip_path:
            return filehandler, filename
        return filehandler


def load_pc_from_zip(zippath, datapath):
    filehandler, filename = open_from_zip(zippath, datapath, return_zip_path=True)
    ext = os.path.splitext(filename)[1][1:]
    mesh = trimesh.load(filehandler, ext, process=False)
    return mesh
