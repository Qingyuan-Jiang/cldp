import matplotlib
import matplotlib.pyplot as plt
import numpy as np


def colorFader(c1, c2, mix=0):  # fade (linear interpolate) from color c1 (at mix=0) to c2 (mix=1)
    c1 = np.array(matplotlib.colors.to_rgb(c1))
    c2 = np.array(matplotlib.colors.to_rgb(c2))
    return matplotlib.colors.to_hex((1 - mix) * c1 + mix * c2)


class Visualizer:

    def __init__(self, extent, alen, d_max, n_pred):
        self.extent = extent
        self.alen = alen
        self.d_max = d_max
        self.n_pred = n_pred
        self.colors_inp = [colorFader('#ff8f06', '#1f06ff', i / n_pred) for i in range(n_pred)]

    def vis_traj_with_occ(self, fname,
                          traj_inp=None,
                          traj_gt=None,
                          traj_ref_vis=None,
                          path=None,
                          occ_map=None,
                          conf=None,
                          pos_h=None,
                          pos_r=None,
                          ):
        """
        Visualize the trajectory with the occupancy map.
        :param fname: The filename of the image.
        :param traj_inp: (n_pred, 2) numpy array.
        :param traj_gt: (n_pred, 2) numpy array.
        :param traj_ref_vis: (n_sample, n_pred, 2) numpy array.
        :param occ_map: (H, W) numpy array.
        :param path: (n_pred, 3) numpy array. Robot trajectory.
        :param conf: (n_sample) numpy array. Confidence score of each trajectory.
        :param pos_h: (2) numpy array. Human position to visualize
        :param pos_r: (2) numpy array. Robot position to visualize
        """
        # print("Visualize occ-map and traj. at %s" % fname)

        # ---------------------------------------------------------------------
        # Now we visualize the optimal path.
        # We first draw the map and the dp path.
        fig, ax = plt.subplots(1, 1)

        if occ_map is not None:
            # Note that the ax.imshow will flip the image.
            ax.imshow(occ_map, cmap='gray', vmin=-1, vmax=1, alpha=0.5, extent=self.extent, origin='lower')

        if traj_inp is not None:
            ax.plot(traj_inp[:, 0], traj_inp[:, 1], c='g', linewidth=6)

        if traj_ref_vis is not None:
            n_sample = traj_ref_vis.shape[0]
            for i_sample in range(n_sample):
                alpha = 0.2 if conf is None else conf[i_sample]
                ax.plot(traj_ref_vis[i_sample, :, 0], traj_ref_vis[i_sample, :, 1], c='r', alpha=alpha, linewidth=6)

        if path is not None:
            n_path = len(path)
            for t in range(n_path):
                ax.arrow(path[t, 0], path[t, 1], self.alen * np.cos(path[t, 2]), self.alen * np.sin(path[t, 2]),
                         color=self.colors_inp[t], head_width=0.2)  # Plot the robot pose as a vector, color in red.
            ax.scatter(path[:, 0], path[:, 1], c=self.colors_inp[-n_path:], s=60)

        if traj_gt is not None:
            ax.plot(traj_gt[:, 0], traj_gt[:, 1], c='b', alpha=0.5, linewidth=6)

        if conf is not None:
            # Draw the confidence score for each trajectory,
            # at the last point of the trajectory.
            n_sample = traj_ref_vis.shape[0]
            for i_sample in range(n_sample):
                offset = 0.5
                angle = np.arctan2(traj_ref_vis[i_sample, -1, 1] - traj_ref_vis[i_sample, -2, 1],
                                   traj_ref_vis[i_sample, -1, 0] - traj_ref_vis[i_sample, -2, 0])
                ax.text(traj_ref_vis[i_sample, -1, 0] + offset * np.cos(angle),
                        traj_ref_vis[i_sample, -1, 1] + offset * np.sin(angle),
                        f"{conf[i_sample]:.2f}", fontsize=8, color='r')
                # ax.text(traj_ref_vis[i_sample, -1, 0], traj_ref_vis[i_sample, -1, 1],
                #         f"{conf[i_sample]:.2f}", fontsize=8, color='r')

            # Write the confidence score into a text file.
            with open(fname.replace('.png', '.txt'), 'w') as f:
                for i_sample in range(n_sample):
                    f.write(f"{conf[i_sample]:.4f}\n")

        if pos_h is not None:
            ax.scatter(pos_h[0], pos_h[1], c='b', s=120)

        if pos_r is not None:
            ax.scatter(pos_r[0], pos_r[1], c='r', s=120)
            ax.arrow(pos_r[0], pos_r[1], self.alen * np.cos(pos_r[2]), self.alen * np.sin(pos_r[2]), color='r',
                     head_width=0.2)

        ax.set_xlim(-self.d_max, self.d_max)
        ax.set_ylim(-self.d_max, self.d_max)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_aspect('equal', 'box')
        plt.tight_layout()
        if fname is None:
            plt.show()
        else:
            plt.savefig(fname, bbox_inches='tight', dpi=600)
            plt.close(fig)
        # ---------------------------------------------------------------------

        return fig, ax
