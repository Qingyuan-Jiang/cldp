import sys
import time
from os.path import abspath, dirname, join

import numpy as np
import torch
import yaml
from einops import repeat

ROOT_DIR = abspath(join(dirname(__file__), '../../'))
sys.path.append(ROOT_DIR)

from src.utils.vis_utils import colorFader


# from torch.utils.tensorboard import SummaryWriter


class DPPlanner:
    PLANNER_NAME = 'dp'

    def __init__(self, cfg_data, cfg_model, args, **kwargs):
        # Load config.
        self.cfg_data = cfg_data
        self.cfg_model = cfg_model
        self.cfg_plan = yaml.safe_load(open(join(ROOT_DIR, f'src/cfg/planner.yml'), 'r'))

        self.n_pred = cfg_data['n_pred']  # Number of predicted frames
        self.d_max = cfg_data['d_max']
        self.n_sample = args.n_sample

        # Setup parameters. -----------------------------------------------------
        # Kinematic constraints.
        self.v_max = self.cfg_plan['kinematics']['v_max']
        self.max_rot = self.cfg_plan['kinematics']['max_rot'] / 180. * np.pi
        self.dt = self.cfg_plan['kinematics']['dt']

        self.offset = self.cfg_plan['plan']['offset']  # Offset for the distance to the human.
        self.penalty = self.cfg_plan['plan']['penalty']  # Penalty for the distance to the human.

        self.verbose = self.cfg_plan['verbose']
        self.latency = self.cfg_plan['latency']
        self.logs = self.cfg_plan['logs']

        self.verbose = args.verbose or self.verbose
        self.logs = args.logs or self.logs
        self.dev = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        # Weight for the value function.
        self.lamb_t = self.cfg_plan['weight']['lamb_t']  # Decay factor for the value function.
        self.lamb_v = self.cfg_plan['weight']['lamb_v']  # Factor for the view planning metric.
        self.lamb_o = self.cfg_plan['weight']['lamb_o']  # Factor for the collision.

        # Setup parameters for the state space discretization.
        self.vs_xy = torch.tensor(self.cfg_plan['plan']['vs_xy'])  # Voxel size in x and y.
        self.vs_theta = torch.tensor(self.cfg_plan['plan']['vs_theta'] / 180. * np.pi)  # Voxel size in theta.
        self.vs_v = torch.tensor(self.cfg_plan['plan']['vs_v'])  # Voxel size in v.
        self.vs_w = torch.tensor(self.cfg_plan['plan']['vs_w'] / 180. * np.pi)

        self.n_voxel_xy = round(2 * self.d_max / self.vs_xy.numpy()) + 1
        self.n_voxel_theta = round(2 * np.pi / self.vs_theta.numpy()) + 1
        self.n_neighbor = round(self.v_max / self.vs_xy.numpy())

        # Discretize the state space and time horizon, prepare the value function.
        # Define the state space as (x, y, theta).
        xx = np.linspace(-self.d_max, self.d_max, self.n_voxel_xy)
        yy = np.linspace(-self.d_max, self.d_max, self.n_voxel_xy)
        rr = np.linspace(-np.pi, np.pi, self.n_voxel_theta)  # Use r for theta to avoid confusion.
        xyr = np.meshgrid(xx, yy, rr)  # Note: xyr is in (x, y, r) order.
        self.xyr = torch.from_numpy(np.stack(xyr, axis=-1).reshape(-1, 3)).to(self.dev)
        self.n_xyr = self.xyr.shape[0]

        # Discretize the action space.
        vv = np.linspace(0, self.v_max, round(self.v_max / self.vs_v.numpy()) + 1)
        ww = np.linspace(-self.max_rot, self.max_rot, round((2 * self.max_rot) / self.vs_w.numpy()) + 1)
        vw = np.meshgrid(vv, ww)
        self.vw = torch.from_numpy(np.stack(vw, axis=-1).reshape(-1, 2)).to(self.dev)
        self.n_vw = self.vw.shape[0]

        # Prepare the value function.
        # Value function is a function of (x, y, theta, t).
        # self.V = torch.zeros((self.n_voxel_xy, self.n_voxel_xy, self.n_voxel_theta, self.n_pred)).to(self.dev)

        # Also prepare the method for state-index conversion.
        self.state2idx = lambda x, y, r: (torch.round((x + self.d_max) / self.vs_xy),
                                          torch.round((y + self.d_max) / self.vs_xy),
                                          torch.round((r + torch.pi) / self.vs_theta))
        self.action2idx = lambda v, w: (torch.round(v / self.vs_xy), torch.round((w + np.pi) / self.vs_theta))

        self.colors_inp = [colorFader('#ff8f06', '#1f06ff', i / self.n_pred) for i in range(self.n_pred)]

        # Prepare the weight among the samples. Assume uniform weight for now.
        self.lamb_samp = torch.ones(self.n_sample).to(self.dev) / self.n_sample

        # We calculate all the potential 'next' state using the transition function.
        # The transition function is a function of (x, y, theta, v, w).
        # (x, y, theta) = (x, y, theta) + (v * cos(theta),
        #                                  v * sin(theta),
        #                                  w).
        #               = (x, y, theta) + B * (v, w).
        # B = [[cos(theta), 0],
        #      [sin(theta), 0],
        #      [0, 1]].
        # Note that we use repeat_interleave to repeat the rows for the states, and repeat for the actions.
        # i.e. (n_xyr, n_vw, 3) and (n_xyr, n_vw, 2) respectively.
        # For states [[x1, y1, r1], [x2, y2, r2]], and actions [[v1, w1], [v2, w2]], for example
        # We order the repeated states as [[x1, y1, r1], [x1, y1, r1], [x1, y1, r1], [x2, y2, r2], [x2, y2, r2]],
        # and the repeated actions as [[v1, w1], [v2, w2], [v1, w1], [v2, w2]].
        with torch.no_grad():
            cos_theta = torch.cos(self.xyr[:, 2]).unsqueeze(1)
            sin_theta = torch.sin(self.xyr[:, 2]).unsqueeze(1)
            B = torch.cat((cos_theta, sin_theta, torch.ones_like(cos_theta)), dim=1)
            # B_rep = B.repeat_interleave(self.n_vw, dim=0)
            # xyr_rep = self.xyr.repeat_interleave(self.n_vw, dim=0)
            xyr_rep = repeat(self.xyr, '(x 1) c -> (x a) c', a=self.n_vw)
            B_rep = repeat(B, '(x 1) c -> (x a) c', a=self.n_vw)
            xyr_next = xyr_rep
            vw_rep = self.vw.repeat(self.n_xyr, 1)
            xyr_next[:, 0] = xyr_next[:, 0] + vw_rep[:, 0] * B_rep[:, 0] * self.dt  # x' = x + v * cos(theta) * dt
            xyr_next[:, 1] = xyr_next[:, 1] + vw_rep[:, 0] * B_rep[:, 1] * self.dt  # y' = y + v * sin(theta) * dt
            xyr_next[:, 2] = xyr_next[:, 2] + vw_rep[:, 1] * B_rep[:, 2] * self.dt  # r' = r + w * dt
            xyr_next[:, 0] = torch.clamp(xyr_next[:, 0], -self.d_max, self.d_max)
            xyr_next[:, 1] = torch.clamp(xyr_next[:, 1], -self.d_max, self.d_max)
            xyr_next[:, 2] = (xyr_next[:, 2] + np.pi) % (2 * np.pi) - np.pi
            self.xyr_next = xyr_next.reshape(self.n_xyr * self.n_vw, 3)  # (n_xyr * n_vw, 3)

    @torch.no_grad()
    def build_cost_map(self, traj, map):
        """
        Given the predicted trajectory (n_samples), we build the cost map for the path planning.
        The cost function is written as two terms.
        The first term is the PPA value, defined by dist / cos(theta).
        The second term is the collision between the local map, defined by the Signed Distance Function (SDF).

        traj: The predicted trajectory, in (n_sample, n_pred, 2) format.
        map: The map of the environment, in (H, W) format.
        return: The cost map, in (n_voxel_xy, n_voxel_xy, n_voxel_theta, n_sample, n_pred) format.
        """
        # We will first calculate the summed cost for each time step separately.
        # Then we will use dynamic programming to iterate the value function.
        tau = torch.from_numpy(traj).to(self.dev)
        n_sample, n_pred, _ = tau.shape
        tau_rep = tau.repeat(self.n_xyr, 1, 1, 1)  # (n_xyr, n_sample, n_pred, 2)
        xy_rep = self.xyr[:, :2].repeat(n_sample, n_pred, 1, 1).permute(2, 0, 1, 3)  # (n_xyr, n_sample, n_pred, 2)
        vec_t2r = xy_rep - tau_rep  # (n_xyr, n_sample, n_pred, 2)
        dist_nsample = torch.norm(vec_t2r, dim=-1)  # (n_xyr, n_sample, n_pred)
        dist_shift = torch.abs(dist_nsample - self.offset) + self.offset  # (n_xyr, n_sample, n_pred)
        # dist_shift = torch.abs(dist_nsample - self.offset)  # (n_xyr, n_sample, n_pred)
        # dist_shift = dist_nsample  # (n_xyr, n_sample, n_pred)
        # idx_dist = dist_nsample < self.offset

        # # Sum over n_sample. Note dist is in (y, x, t) order.
        # self.dist = dist_shift.sum(dim=1).reshape(self.n_voxel_xy, self.n_voxel_xy, self.n_voxel_theta, n_pred)

        # Calculate the heading direction and viewing direction for each state.
        # 1. The heading direction of the human (given trajectory).
        theta = torch.atan2(tau[:, 1:, 1] - tau[:, :-1, 1], tau[:, 1:, 0] - tau[:, :-1, 0])
        theta = torch.cat((theta, theta[:, -1].unsqueeze(1)), dim=1)  # Repeat the last element. (n_sample, n_pred)
        u_tau = torch.cat((torch.cos(theta).unsqueeze(-1), torch.sin(theta).unsqueeze(-1)), dim=-1)
        u_tau_rep = u_tau.unsqueeze(0).repeat(self.n_xyr, 1, 1, 1)  # (n_xyr, n_sample, n_pred, 2)
        # 2. The viewing direction of the robot (given state) in cos(theta).
        u_r = torch.cat((torch.cos(self.xyr[:, 2]).unsqueeze(-1), torch.sin(self.xyr[:, 2]).unsqueeze(-1)), dim=-1)
        u_r_rep = u_r[:, None, None, :].repeat(1, n_sample, n_pred, 1)  # (n_xyr, n_sample, n_pred, 2)
        cos_theta = (u_tau_rep * u_r_rep).sum(-1)
        # cos_theta_filter = torch.max(cos_theta, torch.tensor(0.001)) + 0.5  # Filter out negative values.
        cos_theta_filter = cos_theta + 1  # Shift the value to positive.
        # cos_theta_filter[(vec_t2r * u_tau_rep).sum(-1) < 0] = 1
        # 3. Calculate the PPA values (inverse) defined by dist / cos(theta).
        m_ppa = - (cos_theta_filter / dist_shift)  # Minus PPA.
        # 4. Filter out the states that the robot is behind the human.
        idx_behind = (vec_t2r * u_tau_rep).sum(-1) < 0
        # 5. Only consider the states in the field of view. (2 * 60 degree)
        vec_t2r_norm = vec_t2r / dist_nsample.unsqueeze(-1)
        idx_fov = (vec_t2r_norm * u_r_rep).sum(-1) < np.cos(np.pi / 3)
        m_ppa[idx_behind] = self.penalty  # Set the value to the maximum distance.
        m_ppa[idx_fov] = self.penalty
        # m_ppa[idx_dist] = self.penalty  # Set the value to 0 if the distance is within the offset.
        self.m_ppa = m_ppa.reshape(self.n_voxel_xy, self.n_voxel_xy, self.n_voxel_theta, n_sample, n_pred)

        # # Visualize the summed cost for test purpose. Uncomment this part for visualization.
        # import matplotlib.pyplot as plt
        # import matplotlib
        # matplotlib.use('TkAgg')
        # fig, ax = plt.subplots(1, 1)
        # t = 0  # Time step.
        # i_samp = 0  # Sample index.
        # i_ang = 20  # Angle index.
        # dist_t = self.m_ppa[:, :, i_ang, i_samp, t].cpu().numpy()
        # cax = ax.imshow(dist_t, cmap='jet', alpha=0.5, aspect='auto',
        #                 vmin=- (1 + 1) / self.offset, vmax=0,
        #                 extent=(-self.d_max, self.d_max, -self.d_max, self.d_max), origin='lower')
        # fig.colorbar(cax, ax=ax, orientation='vertical')
        # ax.plot(traj[i_samp, :, 0], traj[i_samp, :, 1], c='r')
        # ax.scatter(traj[i_samp, t, 0], traj[i_samp, t, 1], c='r', s=100)
        # ax.set_xlim(-self.d_max, self.d_max)
        # ax.set_ylim(-self.d_max, self.d_max)
        # ax.set_xticks([])
        # ax.set_yticks([])
        # ax.set_aspect('equal', 'box')
        # plt.tight_layout()
        # plt.show()

        # Calculate the collision cost.
        # First we figure out the states that are occupied in the local map.
        # Only consider the collision with the obstacles (1), not the free space (0) or the unknown (-1).
        map_occ = torch.abs(torch.from_numpy(map)).to(self.dev)  # (n_y, n_x)
        idx_map = torch.round((xy_rep + self.d_max) / (2 * self.d_max) * (map_occ.shape[1] - 1)).long()
        idx_map = torch.clamp(idx_map, 0, map_occ.shape[1] - 1)
        occupied = map_occ[idx_map[:, :, :, 1], idx_map[:, :, :, 0]]  # (n_xyr, n_sample, n_pred)
        # Then we calculate the SDF value for the occupied states.
        # sdf = - dist_nsample + self.epsilon  # (n_xyr, n_sample, n_pred)
        # sdf = torch.clamp(sdf, min=0)
        # sdf = sdf * occupied  # (n_xyr, n_sample, n_pred)
        self.occ = occupied.reshape(self.n_voxel_xy, self.n_voxel_xy, self.n_voxel_theta, n_sample, n_pred).int()

        # # Visualize the sdf function for test purpose. Uncomment this part for visualization.
        # import matplotlib.pyplot as plt
        # import matplotlib
        # matplotlib.use('TkAgg')
        # fig, ax = plt.subplots(1, 1)
        # t = 0  # Time step.
        # i_samp = 0  # Sample index.
        # i_ang = 20  # Angle index.
        # vis = self.occ[:, :, i_ang, i_samp, t].cpu().numpy()
        # ax.imshow(vis, cmap='gray', alpha=0.5, aspect='auto', vmin=0, vmax=1,
        #           extent=(-self.d_max, self.d_max, -self.d_max, self.d_max), origin='lower')
        # ax.scatter(traj[:, t, 0], traj[:, t, 1], c='r')
        # ax.set_xlim(-self.d_max, self.d_max)
        # ax.set_ylim(-self.d_max, self.d_max)
        # ax.set_xticks([])
        # ax.set_yticks([])
        # ax.set_aspect('equal', 'box')
        # plt.tight_layout()
        # plt.show()

        # Combine the two costs.
        self.cost_map = self.lamb_v * self.m_ppa + self.lamb_o * self.occ

    def reference_traj(self, poses_inp, poses_label):
        """
        In this function, we calculate the reference trajectory for the robot to follow.
        traj_ref: the reference trajectory, in (bs, n_sample, n_horizon, 2) format.

        For 'dp' dynamic programming planner, specifically,
        we use the ground truth future trajectory.
        """
        traj_gt = poses_label['pose']['traj'].cpu().numpy()
        traj_gt_repeat = np.repeat(traj_gt, self.n_sample, axis=0)
        return traj_gt_repeat

    @torch.no_grad()
    def interpolate_V_func(self, V, x, y, r, t):
        """
        Given the value function V, we interpolate the value function at the state (x, y, r, t).
        """
        # First we calculate the index of the state.
        i = (x + self.d_max) / self.vs_xy
        j = (y + self.d_max) / self.vs_xy
        k = (r + np.pi) / self.vs_theta
        i_f, i_c = torch.floor(i), torch.ceil(i)
        j_f, j_c = torch.floor(j), torch.ceil(j)
        k_f, k_c = torch.floor(k), torch.ceil(k)
        i_f, i_c = torch.clamp(i_f, 0, self.n_voxel_xy - 1), torch.clamp(i_c, 0, self.n_voxel_xy - 1)
        j_f, j_c = torch.clamp(j_f, 0, self.n_voxel_xy - 1), torch.clamp(j_c, 0, self.n_voxel_xy - 1)
        k_f, k_c = torch.clamp(k_f, 0, self.n_voxel_theta - 1), torch.clamp(k_c, 0, self.n_voxel_theta - 1)
        # Trilinear interpolation
        V_interp = (
                V[j_f.long(), i_f.long(), k_f.long(), t] * (i_c - i) * (j_c - j) * (k_c - k) +
                V[j_f.long(), i_f.long(), k_c.long(), t] * (i_c - i) * (j_c - j) * (k - k_f) +
                V[j_f.long(), i_c.long(), k_f.long(), t] * (i - i_f) * (j_c - j) * (k_c - k) +
                V[j_f.long(), i_c.long(), k_c.long(), t] * (i - i_f) * (j_c - j) * (k - k_f) +
                V[j_c.long(), i_f.long(), k_f.long(), t] * (i_c - i) * (j - j_f) * (k_c - k) +
                V[j_c.long(), i_f.long(), k_c.long(), t] * (i_c - i) * (j - j_f) * (k - k_f) +
                V[j_c.long(), i_c.long(), k_f.long(), t] * (i - i_f) * (j - j_f) * (k_c - k) +
                V[j_c.long(), i_c.long(), k_c.long(), t] * (i - i_f) * (j - j_f) * (k - k_f)
        )
        return V_interp

    @torch.no_grad()
    def plan(self, pose, traj, map, build_cost_map=True, t_curr=0, **kwargs):
        """
        Given a few trajectory of the future (n_samples, either predicted or from ground truth),
        we plan the optimal path using dynamic programming.
        Denote the trajectory as tau = {x_0, x_1, ..., x_{n_pred}}.
        Define the cost function J = sum_{t=0}^{n_pred} lambda_{tau} sum_{i=1}^{n_sample} ||x_i - tau_t||_2^2.
        Find the optimal action u = (v, w) at each time step t, such that J is minimized.
        :param pose: The robot position, in (x, y, theta) format.
        :param traj: The desired trajectory, in (n_sample, n_pred, 2) format.
        :param map: The map of the environment, in (H, W) format.
        :param build_cost_map: Whether to build the cost map for the planner, need to be set to True for the first time.
        :param t_curr: The current time step. By default, we assume we are at time 0, planning to n_pred steps.
        """

        # Count calculation time.
        start_time = time.time()

        # Build the cost map.
        self.build_cost_map(traj, map) if build_cost_map else False

        # Reset the value function.
        V = torch.zeros((self.n_voxel_xy, self.n_voxel_xy, self.n_voxel_theta, self.n_pred)).to(self.dev)

        # Set up the value function at the last time step.
        # dist = torch.norm(xy - r, dim=1).reshape(n_voxel, n_voxel)  # Note dist is in (y, x) order.
        # Sum over n_sample using the weight lambda_weight. Note dist is in (y, x, t) order.
        cost_map_weighted = self.lamb_samp[None, None, None, :] * self.cost_map[:, :, :, :, -1]
        # V[:, :, :, -1] = cost_map_weighted.sum(dim=-1)
        # Repeat the cost map for the rest of the time steps. (x, y, theta, n_steps), n_steps = n_pred - t_curr.
        cost_map_weighted_rep = repeat(cost_map_weighted.mean(dim=-1), 'x y t -> x y t n', n=t_curr + 1)
        V[:, :, :, -(t_curr + 1):] = cost_map_weighted_rep

        # Construct value function using dynamic programming, from the last time step to the first.
        for t in reversed(range(self.n_pred - 1)):
            # print('[DP] Construct value function at time step: ', t) if Verbose else False
            # # Get index of the next state.
            # i, j, k = self.state2idx(self.xyr_next[:, 0], self.xyr_next[:, 1], self.xyr_next[:, 2])
            # i, j, k = i.long(), j.long(), k.long()
            # V_next = V[j, i, k, t + 1].reshape(self.n_xyr, self.n_vw)  # order could be wrong
            V_next = self.interpolate_V_func(V,
                                             self.xyr_next[:, 0], self.xyr_next[:, 1], self.xyr_next[:, 2],
                                             t + 1).reshape(self.n_xyr, self.n_vw)  # order could be wrong
            V_min = V_next.min(dim=1).values.reshape(self.n_voxel_xy, self.n_voxel_xy, self.n_voxel_theta)

            # Construct among all the state-action pairs.
            t_ = min(t + t_curr, self.n_pred - 1)
            cost_map_weighted = self.lamb_samp[None, None, None, :] * self.cost_map[:, :, :, :, t_]
            V[:, :, :, t] = cost_map_weighted.mean(dim=-1) + self.lamb_t * V_min

            # # Visualize the minimum value function for test purpose. Uncomment this part for visualization.
            # import matplotlib.pyplot as plt
            # import matplotlib
            # matplotlib.use('TkAgg')
            # v_min_vis = V_min.cpu().numpy()
            # idx_theta = 0
            # fig, ax = plt.subplots(1, 1)
            # ax.imshow(v_min_vis[:, :, idx_theta], cmap='jet', alpha=0.5, vmin=0, vmax=2, aspect='auto',
            #           extent=(-self.d_max, self.d_max, -self.d_max, self.d_max), origin='lower')
            # # ax.scatter(traj[0, t, 0], traj[0, t, 1], c='r')
            # ax.set_xlim(-self.d_max, self.d_max)
            # ax.set_ylim(-self.d_max, self.d_max)
            # ax.set_xticks([])
            # ax.set_yticks([])
            # ax.set_aspect('equal', 'box')
            # plt.tight_layout()
            # plt.show()

        # # ---------------------------------------------------------------------
        # # Now we visualize the value function.
        # import matplotlib.pyplot as plt
        # import matplotlib
        # matplotlib.use('TkAgg')
        # vis_step = 3
        # fig, axs = plt.subplots(1, self.n_pred // vis_step)
        # for t in range(0, self.n_pred, vis_step):
        #     ax = axs[t // vis_step]
        #     # v_t_vis = V[:, :, t].cpu().numpy().transpose()
        #     v_t_vis = V[:, :, 0, t].cpu().numpy()  # theta = 0
        #     ax.imshow(v_t_vis, cmap='jet', alpha=0.5, vmin=0, vmax=8, aspect='auto',
        #               extent=(-self.d_max, self.d_max, -self.d_max, self.d_max), origin='lower')
        #     ax.scatter(traj[0, t, 0], traj[0, t, 1], c='r')
        #     ax.plot(traj[0, :, 0], traj[0, :, 1], c='r')
        #     ax.set_xlim(-self.d_max, self.d_max)
        #     ax.set_ylim(-self.d_max, self.d_max)
        #     ax.set_xticks([])
        #     ax.set_yticks([])
        #     ax.set_aspect('equal', 'box')
        # plt.tight_layout()
        # plt.show()
        # # ---------------------------------------------------------------------

        # ---------------------------------------------------------------------
        # Given the value function, we calculate the optimal path using dynamic programming.
        pose_t = torch.from_numpy(pose).to(self.dev)
        path = [pose_t]
        for t in range(self.n_pred):
            # print('[DP] Calculate optimal path at time step: ', t) if self.verbose else False
            # Calculate the potential next state.
            B = torch.tensor([[torch.cos(pose_t[2]), 0],
                              [torch.sin(pose_t[2]), 0],
                              [0, 1]]).to(self.dev)
            pose_rep = pose_t[None, :].repeat(self.n_vw, 1)
            pose_next_rep = pose_rep + (B @ self.vw.T).T * self.dt
            pose_next_rep[:, 0] = torch.clamp(pose_next_rep[:, 0], -self.d_max, self.d_max)
            pose_next_rep[:, 1] = torch.clamp(pose_next_rep[:, 1], -self.d_max, self.d_max)
            pose_next_rep[:, 2] = (pose_next_rep[:, 2] + np.pi) % (2 * np.pi) - np.pi

            # Get index of the next state.
            # i, j, k = self.state2idx(pose_next_rep[:, 0], pose_next_rep[:, 1], pose_next_rep[:, 2])
            # i, j, k = i.long(), j.long(), k.long()
            # v_next = V[j, i, k, t]
            v_next = self.interpolate_V_func(V, pose_next_rep[:, 0], pose_next_rep[:, 1], pose_next_rep[:, 2], t)
            idx = torch.argmin(v_next)
            # v_min = v_next.min(dim=1).values

            # Iterate the pose.
            pose_next = pose_t + (B @ self.vw[idx].unsqueeze(0).T).T * self.dt
            pose_next = pose_next.squeeze(0)
            pose_next[0] = torch.clip(pose_next[0], -self.d_max, self.d_max)
            pose_next[1] = torch.clip(pose_next[1], -self.d_max, self.d_max)
            pose_next[2] = (pose_next[2] + torch.pi) % (2 * torch.pi) - torch.pi
            path.append(pose_next)
            pose_t = pose_next
        # ---------------------------------------------------------------------

        path = torch.stack(path).cpu().numpy()[1:]

        # # ---------------------------------------------------------------------
        # # Now we visualize the optimal path.
        # import matplotlib.pyplot as plt
        # import matplotlib
        # matplotlib.use('TkAgg')
        # alen = self.v_max * self.dt * 0.5
        # fig, axs = plt.subplots(1, 1)
        # axs.imshow(V[:, :, 0, -1].cpu().numpy(), cmap='gray', alpha=0.5,
        #            extent=(-self.d_max, self.d_max, -self.d_max, self.d_max), origin='lower')
        # axs.plot(traj[0, :, 0], traj[0, :, 1], c='r')  # For test purpose,
        # axs.scatter(path[:, 0], path[:, 1], c=self.colors_inp)
        # for t in range(self.n_pred):
        #     axs.arrow(path[t, 0], path[t, 1], alen * np.cos(path[t, 2]), alen * np.sin(path[t, 2]),
        #               color=self.colors_inp[t], head_width=0.05)  # Plot the robot pose as a vector, color in red.
        # axs.set_xlim(-self.d_max, self.d_max)
        # axs.set_ylim(-self.d_max, self.d_max)
        # axs.set_xticks([])
        # axs.set_yticks([])
        # axs.set_aspect('equal', 'box')
        # plt.tight_layout()
        # plt.show()
        # # ---------------------------------------------------------------------

        # Print the calculation time.
        end_time = time.time()
        time_delta = end_time - start_time
        print(f'[DP] Path planning time: {time_delta:.4f}s at current time {t_curr:02d}') if self.verbose else None
        info = {'time': time_delta}
        return path, info
