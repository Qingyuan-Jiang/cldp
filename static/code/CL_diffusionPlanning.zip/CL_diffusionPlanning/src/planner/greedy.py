import sys
import time
from os.path import abspath, dirname, join

import numpy as np
import torch

ROOT_DIR = abspath(join(dirname(__file__), '../../'))
sys.path.append(ROOT_DIR)

# from datasets.dataset_test import DatasetGTA
from src.planner.dp import DPPlanner


class GreedyPlanner(DPPlanner):
    PLANNER_NAME = 'greedy'

    def __init__(self, cfg_data, cfg_model, args, **kwargs):
        super(GreedyPlanner, self).__init__(cfg_data, cfg_model, args, **kwargs)
        self.extent = (-self.d_max, self.d_max, -self.d_max, self.d_max)

    def reference_traj(self, poses_inp, poses_label):
        """
        In this function, we calculate the reference trajectory for the robot to follow.
        traj_ref: the reference trajectory, in (bs, n_sample, n_horizon, 2) format.

        For 'greedy' planner, specifically,
        we use the ground truth future trajectory.
        """
        traj_gt = poses_label['pose']['traj'].cpu().numpy()

        # Shift the trajectory ground truth by the latency.
        traj_ref = np.zeros_like(traj_gt)
        traj_ref[:, self.latency:] = traj_gt[:, :-self.latency] if self.latency > 0 else traj_gt
        traj_ref_repeat = np.repeat(traj_ref, self.n_sample, axis=0)
        return traj_ref_repeat

    def plan(self, pose, traj, map, build_cost_map=True, **kwargs):
        """
        Given the predicted trajectory (n_samples), we plan the optimal path using dynamic programming.
        Denote the trajectory as tau = {x_0, x_1, ..., x_{n_pred}}.
        Define the cost function J = sum_{t=0}^{n_pred} sum_{i=1}^{n_sample} ||x_i - tau_t||_2^2.
        Find the optimal action u = (v, w) at each time step t, such that J is minimized.
        :param pose: The robot position, in (x, y, theta) format.
        :param traj: The desired trajectory, in (n_sample, n_pred, 2) format.
        :param map: The map of the environment, in (H, W) format.
        :param build_cost_map: Whether to build the cost map for the planner, need to be set to True for the first time.
        """

        # Count calculation time.
        ts = time.time()

        # Build the cost map.
        self.build_cost_map(traj, map) if build_cost_map else False

        # Set up the value function at the last time step.
        # dist = torch.norm(xy - r, dim=1).reshape(n_voxel, n_voxel)  # Note dist is in (y, x) order.
        # Sum over n_sample using the weight lambda_weight. Note dist is in (y, x, t) order.
        cost_map_weighted = self.lamb_samp[None, None, None, :, None] * self.cost_map[:, :, :, :, :]
        cost_map = cost_map_weighted.sum(dim=-2)  # Sum over the n_sample dimension. (n_voxel, n_voxel, n_theta, n_time)

        # ---------------------------------------------------------------------
        # Given the cost function for each state we calculate the optimal path using greedy algorithm.
        pose = torch.from_numpy(pose).to(self.dev)
        path = [pose]
        for t in range(1, self.n_pred):
            # # ----------------------------------------------------------------
            # # Test code for the cost map. Comment out if not needed.
            # import matplotlib
            # import matplotlib.pyplot as plt
            # matplotlib.use('TkAgg')
            # ang = 0
            # v_step = self.v_max * self.dt
            # pose_vis = pose.cpu().numpy()
            # fig, ax = plt.subplots(1, 1)
            # cax = ax.imshow(cost_map[:, :, ang, t].cpu().numpy(),
            #                 cmap='jet', alpha=0.5, extent=self.extent, origin='lower')
            # plt.plot(traj[0, :, 0], traj[0, :, 1])
            # plt.scatter(traj[0, t, 0], traj[0, t, 1], c='r')
            # plt.scatter(pose_vis[0], pose_vis[1], c='b')
            # plt.arrow(pose_vis[0], pose_vis[1],
            #           v_step * np.cos(pose_vis[2]), v_step * np.sin(pose_vis[2]), color='b', head_width=0.05)
            # fig.colorbar(cax, ax=ax, orientation='vertical')
            # ax.set_xlim(-self.d_max, self.d_max)
            # ax.set_ylim(-self.d_max, self.d_max)
            # ax.set_xticks([])
            # ax.set_yticks([])
            # ax.set_aspect('equal', 'box')
            # plt.tight_layout()
            # plt.show()
            # # ----------------------------------------------------------------

            # Calculate the potential next state.
            B = torch.tensor([[torch.cos(pose[2]), 0],
                              [torch.sin(pose[2]), 0],
                              [0, 1]]).to(self.dev)
            pose_rep = pose[None, :].repeat(self.n_vw, 1)
            pose_next_rep = pose_rep + (B @ self.vw.T).T * self.dt
            pose_next_rep[:, 0] = torch.clamp(pose_next_rep[:, 0], -self.d_max, self.d_max)
            pose_next_rep[:, 1] = torch.clamp(pose_next_rep[:, 1], -self.d_max, self.d_max)
            pose_next_rep[:, 2] = (pose_next_rep[:, 2] + np.pi) % (2 * np.pi) - np.pi

            # Get index of the next state.
            # i, j, k = self.state2idx(pose_next_rep[:, 0], pose_next_rep[:, 1], pose_next_rep[:, 2])
            # i, j, k = i.long(), j.long(), k.long()
            # v_next = cost_map[j, i, k, t]
            v_next = self.interpolate_V_func(cost_map, pose_next_rep[:, 0], pose_next_rep[:, 1], pose_next_rep[:, 2], t)
            idx = torch.argmin(v_next)
            # v_min = v_next.min(dim=1).values

            # Iterate the pose.
            pose_next = pose + (B @ self.vw[idx].unsqueeze(0).T).T * self.dt
            pose_next = pose_next.squeeze(0)
            pose_next[0] = torch.clip(pose_next[0], -self.d_max, self.d_max)
            pose_next[1] = torch.clip(pose_next[1], -self.d_max, self.d_max)
            pose_next[2] = (pose_next[2] + torch.pi) % (2 * torch.pi) - torch.pi
            path.append(pose_next)
            pose = pose_next
        # ---------------------------------------------------------------------

        path = torch.stack(path).cpu().numpy()

        # # ---------------------------------------------------------------------
        # # Now we visualize the optimal path.
        # alen = self.v_max * self.dt * 0.5
        # fig, axs = plt.subplots(1, 1)
        # axs.imshow(self.V[:, :, 0, -1].numpy(), cmap='gray', alpha=0.5,
        #            extent=(-self.d_max, self.d_max, -self.d_max, self.d_max), origin='lower')
        # axs.plot(traj[0, :, 0], traj[0, :, 1], c='r')  # For test purpose,
        # axs.scatter(path[:, 0], path[:, 1], c=self.colors_inp)
        # for t in range(self.n_time):
        #     axs.arrow(path[t, 0], path[t, 1], alen * np.cos(path[t, 2]), alen * np.sin(path[t, 2]),
        #               color=self.colors_inp[t], head_width=0.05)  # Plot the robot pose as a vector, color in red.
        # axs.set_xlim(-self.d_max, self.d_max)
        # axs.set_ylim(-self.d_max, self.d_max)
        # axs.set_xticks([])
        # axs.set_yticks([])
        # axs.set_aspect('equal', 'box')
        # plt.tight_layout()
        # plt.show()
        # # ---------------------------------------------------------------------

        # Print the calculation time.
        te = time.time()
        t_delta = te - ts
        print('[Greedy] Path planning time: {:.4f} s'.format(t_delta)) if self.verbose else False
        info = {
            'time': t_delta,
        }
        return path, info
