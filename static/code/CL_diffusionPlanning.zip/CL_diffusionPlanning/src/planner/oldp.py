import os
import sys
import time
from os.path import abspath, dirname, join

import torch

ROOT_DIR = abspath(join(dirname(__file__), '../../'))
sys.path.append(ROOT_DIR)

from src.planner.dp import DPPlanner
from src.models.motion_pred import get_model


class OpenLoopDiffusionPlanner(DPPlanner):
    PLANNER_NAME = 'oldp'

    def __init__(self, cfg_data, cfg_model, args, **kwargs):
        # construct model
        # Load config.
        super().__init__(cfg_data, cfg_model, args, **kwargs)
        data_name = cfg_data['dataset']
        model = cfg_model['model_name']
        name_specs = cfg_model['model_specs']['name_specs']
        model_name = model + '_' + name_specs

        self.pose_predictor = get_model(cfg_data, cfg_model).to(dtype=torch.float32, device=self.dev)

        epoch = args.epoch

        exp_dir = os.path.join(ROOT_DIR, f'results/{data_name}_{model_name}_{args.exp}/')
        weights_dir = os.path.join(exp_dir, 'models')
        os.makedirs(weights_dir, exist_ok=True)
        net_path_save = join(weights_dir, 'net_{:03d}.pt'.format(epoch))
        self.pose_predictor.load_model(net_path_save)
        self.pose_predictor.eval()
        print(f'Loaded model from {net_path_save}')
        print(f'Number of parameters: {self.pose_predictor.num_of_params():.04f}M')

    def reference_traj(self, poses_inp, poses_label):
        """
        In this function, we calculate the reference trajectory for the robot to follow.
        traj_ref: the reference trajectory, in (n_sample, n_horizon, 2) format.

        For 'closed-loop' diffusion planner, specifically,
        we use the predicted trajectory samples from the diffusion model as the reference trajectory.
        """
        print('[OLDP] Calculating reference trajectory...') if self.verbose else False
        ts = time.time()
        poses_outp = self.pose_predictor.inference(poses_inp, n_sample=self.n_sample, sampler='ddpm')
        traj_pred = poses_outp['pose']['traj'].cpu().numpy()
        # loss = F.mse_loss(torch.from_numpy(traj_pred), torch.from_numpy(traj_gt_repeat))
        # print(f'Loss: {loss}')
        # print(traj_pred[0])
        te = time.time()
        print(f'[OLDP] Calculating reference trajectory done! Time: {te - ts:.04f}s') if self.verbose else False
        return traj_pred
