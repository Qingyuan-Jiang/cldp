import sys
import time
from os.path import abspath, dirname, join

import numpy as np
import torch
import yaml

ROOT_DIR = abspath(join(dirname(__file__), '../../'))
sys.path.append(ROOT_DIR)

from src.planner.oldp import OpenLoopDiffusionPlanner


class ClosedLoopDiffusionPlanner(OpenLoopDiffusionPlanner):
    PLANNER_NAME = 'cldp'

    def __init__(self, cfg_data, cfg_model, args, **kwargs):
        super().__init__(cfg_data, cfg_model, args, **kwargs)
        self.cfg_plan = yaml.safe_load(open(join(ROOT_DIR, f'src/cfg/planner.yml'), 'r'))
        self.gamma = self.cfg_plan['plan']['gamma']  # temperature parameter for posterior probability.
        self.sigma = self.cfg_plan['plan']['sigma']  # discount factor along the time dimension.

    def get_posterior_probability(self, traj_obs, traj_pred):
        """
        Calculate the posterior probability of the predicted trajectory given the observations.
        :param traj_obs: (bs, n_sample, n_obs, 2) array. The observed trajectory.
        :param traj_pred: (bs, n_sample, n_pred, 2) array. The predicted trajectory.
        :return: (bs, n_sample) array. The posterior probability.
        """
        n_obs = traj_obs.shape[2]
        dist = np.linalg.norm(traj_obs - traj_pred[:, :, :n_obs], axis=-1)

        # Multiply the distance with the discount factor gamma and sum over the time dimension.
        df = self.gamma ** np.arange(n_obs)[::-1]
        dist_mean = np.sum(dist * df[None, None, :], axis=-1)
        prob_norm = (np.exp(-dist_mean ** 2 / (2 * self.sigma ** 2))
                     / np.sum(np.exp(-dist_mean ** 2 / (2 * self.sigma ** 2))))
        # # Normalize the probability. (This is deprecated. We should use temperature param to tune).
        # prob_norm = (prob_norm - prob_norm.min()) / (prob_norm.max() - prob_norm.min())
        return prob_norm

    def update_weight_posterior(self, traj_obs, traj_pred):
        print(f"[CLDP] Updating the weight of the posterior probability...") if self.verbose else False
        prob_norm = self.get_posterior_probability(traj_obs[None, ...], traj_pred[None, ...])
        self.lamb_samp = torch.from_numpy(prob_norm.squeeze(0)).to(self.dev)

    def plan(self, pose, traj, map, **kwargs):
        """
        Given the predicted trajectory (n_samples), we plan the optimal path using dynamic programming.
        Denote the trajectory as tau = {x_0, x_1, ..., x_{n_pred}}.
        Define the cost function J = sum_{t=0}^{n_pred} lambda_{tau} sum_{i=1}^{n_sample} ||x_i - tau_t||_2^2.
        Find the optimal action u = (v, w) at each time step t, such that J is minimized.
        :param pose: The robot pose (x, y, theta), in (3, ) format.
        :param traj: The desired trajectory, in (n_sample, n_pred, 2) format.
        :param map: The map of the environment, in (H, W) format.
        """
        ts = time.time()

        traj_gt = kwargs['traj_gt']
        traj_gt_repeat = np.repeat(traj_gt[None, :, :], self.n_sample, axis=0)
        traj_gt_vis = traj_gt_repeat.reshape((self.n_sample, self.n_pred, 2))

        path_cldp = []
        path_logs = []
        lamb_logs = []
        # path = super().plan(pose, traj, map, build_cost_map=True, **kwargs)
        # pose = path[0]
        # path_cldp.append(pose)

        for t in range(0, self.n_pred):

            # # Store the previous pose. Visualization purpose.
            # pose_past = pose.copy()

            # Update the weight of the posterior probability.
            self.update_weight_posterior(traj_gt_vis[:, :t + 1], traj)
            path, info_t = super().plan(pose, traj, map, build_cost_map=(t == 0), t_curr=t, **kwargs)
            pose = path[0]  # Execute one step and plan again.
            path_cldp.append(pose)

            if self.logs:
                path_logs.append(path)
                lamb_logs.append(self.lamb_samp.cpu().numpy())

            # # Visualization of the path. Uncomment for visualization.
            # from src.utils.vis_utils import Visualizer
            # viser = Visualizer((-self.d_max, self.d_max, -self.d_max, self.d_max), 0.25, self.d_max, self.n_pred)
            # fname = f'{t:02d}.png'
            # viser.vis_traj_with_occ(fname=fname,
            #                         traj_inp=kwargs['traj_inp'],
            #                         traj_gt=traj_gt,
            #                         traj_ref_vis=traj,
            #                         occ_map=map,
            #                         path=path,
            #                         conf=self.lamb_samp.cpu().numpy(),
            #                         pos_h=traj_gt[t],
            #                         pos_r=pose_past)

        te = time.time()
        time_delta = te - ts
        print(f'[CLDP] Total planning time: {time_delta:.4f}s') if self.verbose else None
        info = {
            'time': time_delta,
            'path_logs': path_logs,
            'lamb_logs': lamb_logs
        }
        return np.stack(path_cldp), info
