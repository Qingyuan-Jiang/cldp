from src.models.diffusion import DiffusionPredictor
from src.models.cvae_1d import CVAE_1d
from src.models.path_pred import PathPred

named_models = {
    'dif': DiffusionPredictor,
    'cvae': CVAE_1d,
    'base': PathPred,
}


def get_model(cfg_data, cfg_model):
    model_name = cfg_model['model_name']
    return named_models[model_name](cfg_data, cfg_model)
