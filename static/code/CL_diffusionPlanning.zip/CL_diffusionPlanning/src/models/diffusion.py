import torch

from src.diffusion.samp_ddim import SamplerDDIM
from src.diffusion.samp_ddpm import SamplerDDPM, SampleDDPMPerturb
from src.models.dif_base import DiffusionBase
from src.models.dif_film import DiffusionFilm
from src.models.dif_tr import TransformerUnet
from src.models.dif_unet import ConditionalUnet1D
from src.models.predictor_base import BasePredictor

DiffusionCfg = {
    'mlp': DiffusionBase,
    'film': DiffusionFilm,
    'unet': ConditionalUnet1D,
    'tr': TransformerUnet,
}

SamplerCfg = {
    'ddpm': SamplerDDPM,
    'ddpm_perturb': SampleDDPMPerturb,
    'ddim': SamplerDDIM,
}


class DiffusionPredictor(BasePredictor):
    """
    This class is the wrapper of the Diffusion model.
    It deals with all the Diffusion related stuffs.
    """

    def __init__(self, cfg_data, cfg_model):
        super(DiffusionPredictor, self).__init__(cfg_data, cfg_model)

        # Use the Diffusion model above to predict the noise.
        self.model = DiffusionCfg[cfg_model['model_specs']['name_specs']](cfg_data, cfg_model)
        self.sampler = SamplerCfg[cfg_model['sampler']](cfg_data, cfg_model)

        self.n_sample = None
        self.timesteps = cfg_model['model_specs']['timesteps']

    # Helper function: Normalize / denormalize the trajectory to [-1, 1]
    def normalize(self, traj):
        return traj / self.d_max

    def unnormalize(self, traj):
        return traj * self.d_max

    def learn(self, poses_inp):
        """
        poses_inp: a dictionary containing the input poses.
        'env': a dictionary containing the environment information.
            - 'map': the context map.
        'pose': a dictionary containing the pose information.
            - 'pose': the input pose.
            - 'pose_gt': the ground truth pose.
        """
        self.model.train()

        # pred_info = {'pose': pose_pred, 'traj_map': traj_map_pred, 'traj': traj_raw}
        traj_gt = poses_inp['pose']['traj_gt'].to(self.device).float()

        # Note that the trajectory are in range [-max_distance, max_distance]
        # We need to normalize it to [-1, 1]
        # traj = self.normalize(traj)
        # traj_gt = self.normalize(traj_gt)

        # perturb data
        noise = torch.randn_like(traj_gt)
        t = torch.randint(1, self.timesteps, (traj_gt.shape[0],)).to(self.device)
        x_pert = self.sampler.q_sample(traj_gt, t, noise)

        # use network to recover noise
        pred_noise = self.model(x_pert, t / self.timesteps, poses_inp)

        pred_info = {'noise_pred': pred_noise, 'noise_gt': noise}
        pred = {'env': poses_inp['env'], 'pose': pred_info}
        return pred

    def inference(self, inp, n_sample=1, sampler="ddpm"):
        self.model.eval()

        self.n_sample = n_sample
        map = inp['env']['map'] if self.use_map_cond else None
        traj = inp['pose']['traj'] if self.use_traj_cond else None
        pose = inp['pose']['pose'] if self.use_pose_cond else None

        if self.use_map_cond:
            bs = map.shape[0]
        elif self.use_traj_cond:
            bs = traj.shape[0]
        elif self.use_pose_cond:
            bs = pose.shape[0]
        else:
            raise ValueError("No condition provided.")

        # Note that the trajectory are in range [-max_distance, max_distance]
        # We need to normalize it to [-1, 1]
        # traj_norm = self.normalize(traj)

        # For each sample in the batch, we sample n_sample times.
        # Therefore, we repeat inputs traj and map n_sample times.
        # traj_rep = traj_norm.repeat(n_sample, 1, 1)
        traj_rep = traj.repeat_interleave(n_sample, dim=0) if traj is not None else None
        map_rep = map.repeat_interleave(n_sample, dim=0) if map is not None else None
        pose_rep = pose.repeat_interleave(n_sample, dim=0) if pose is not None else None
        # Note that we use repeat_interleave instead of repeat.
        # This is because repeat_interleave will repeat the elements of the tensor,
        # while repeat will repeat the tensor itself.
        # For example, if we have a tensor [1, 2, 3], repeat will give [1, 2, 3, 1, 2, 3],
        # while repeat_interleave will give [1, 1, 2, 2, 3, 3].

        # # Visualize the repeated trajectory. Uncomment this part for visualization.
        # h, w = pose.shape[0], n_sample
        # fig, axs = plt.subplots(h, w, figsize=(w, h))
        # traj_vis = traj_rep.cpu().numpy()
        # for i in range(h):
        #     for j in range(w):
        #         axs[i, j].scatter(traj_vis[i * w + j, :, 0], traj_vis[i * w + j, :, 1])
        #         axs[i, j].set_xlim(-1, 1)
        #         axs[i, j].set_ylim(-1, 1)
        #         axs[i, j].set_aspect('equal', 'box')
        #         axs[i, j].set_xticks([])
        #         axs[i, j].set_yticks([])
        # plt.tight_layout()
        # plt.show()

        size = (bs * n_sample, self.n_pred, 2)
        cond_inp = {'env': {'map': map_rep}, 'pose': {'traj': traj_rep, 'pose': pose_rep}}
        samples, intermediate = self.sampler.p_sample(self.model, size, cond_inp)

        # Denormalize the samples
        # samples = self.unnormalize(samples)
        # intermediate = self.unnormalize(intermediate)

        pred_info = {'traj': samples, 'intermediate': intermediate}
        pred = {'env': inp['env'], 'pose': pred_info}
        return pred
