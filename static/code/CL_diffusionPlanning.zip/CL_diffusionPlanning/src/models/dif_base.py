import torch
import torch.nn as nn
from einops import rearrange

from src.models.cond_model import CondModel


class DiffusionBase(nn.Module):
    """
    This class is a simplest (base) implementation of the Diffusion model.
    It predicts the noise given the input trajectory and the context map.
    """

    def __init__(self, cfg_data, cfg_model):
        super(DiffusionBase, self).__init__()

        # Setup parameters
        self.n_hist = n_hist = cfg_data['n_hist']  # Number of history frames
        self.n_pred = n_pred = cfg_data['n_pred']  # Number of predicted frames
        self.n_feat = n_feat = cfg_model['model_specs']['n_feats']  # Number of features in MLP
        self.map_size = cfg_data['map_size']  # Size of the map. Default 64x64

        # Now we construct the network
        layers = [
            nn.Flatten(start_dim=1),
            nn.Linear(n_hist * 2, n_hist * n_feat),
            nn.ReLU(),
            nn.Linear(n_hist * n_feat, n_pred * n_feat),
        ]

        self.x_emb = nn.Sequential(*layers)

        layers_t = [
            nn.Linear(1, n_hist * n_feat),
            nn.ReLU(),
            nn.Linear(n_hist * n_feat, n_pred * n_feat),
        ]
        self.t_emb = nn.Sequential(*layers_t)

        self.scene_model = CondModel(cfg_data, cfg_model)
        self.cond_dim = self.scene_model.cond_dim

        layers_out = [
            nn.Flatten(start_dim=1),
            nn.Linear(n_pred * (n_feat * 2 + self.cond_dim), n_pred * n_feat),
            nn.ReLU(),
            nn.Linear(n_pred * n_feat, n_pred * n_feat),
            nn.ReLU(),
            nn.Linear(n_pred * n_feat, n_pred * 2),
        ]
        self.out = nn.Sequential(*layers_out)

    def forward(self, x, t, cond_inp):
        """
        x : (batch, n * 2) : input image
        t : (batch, n_cfeat)      : time step
        traj_hist : (batch, n * 2)    : context label
        """
        bs = x.shape[0]
        x = x.reshape(bs, -1)
        t = t.reshape(bs, -1)
        # traj = traj.reshape(bs, -1)
        # tjm = tjm.reshape(bs, -1)

        x_emb = self.x_emb(x)
        x_emb = rearrange(x_emb, 'b (l c) -> b l c', l=self.n_pred)

        t_emb = self.t_emb(t)
        t_emb = rearrange(t_emb, 'b (l c) -> b l c', l=self.n_pred)

        # Condition embedding
        cond_emb = self.scene_model(cond_inp)

        out = self.out(torch.cat([x_emb, t_emb, cond_emb], dim=-1))
        out = rearrange(out, 'b (l c) -> b l c', l=self.n_pred)
        return out
