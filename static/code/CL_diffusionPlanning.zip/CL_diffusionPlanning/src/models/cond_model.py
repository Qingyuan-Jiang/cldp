import torch
import torch.nn as nn
import torchvision
from einops import repeat, rearrange
from einops.layers.torch import Rearrange

blk = lambda ic, oc: nn.Sequential(
    nn.Conv1d(ic, oc, 3, padding=1),
    nn.BatchNorm1d(oc),
    nn.LeakyReLU(),
)


class CondMap(nn.Module):
    def __init__(self, cfg_data, cfg_model):
        super(CondMap, self).__init__()
        self.n_emb_map = cfg_model['cond_specs']['n_emb_map']

        map_enc_type = cfg_model['cond_specs']['map_enc']
        if map_enc_type == 'conv2d':
            layers_map = [
                nn.Conv2d(3, 16, 3, stride=2, padding=1),
                nn.Mish(),
                nn.Conv2d(16, 32, 3, stride=2, padding=1),
                nn.Mish(),
                nn.Conv2d(32, 64, 3, stride=2, padding=1),
                nn.Mish(),
                nn.Conv2d(64, 64, 3, stride=2, padding=1),
                nn.Mish(),
                Rearrange('b c h w -> b (c h w)'),
                nn.Linear(1024, self.n_emb_map)
            ]
            self.map_enc = nn.Sequential(*layers_map)

        elif map_enc_type == 'resnet18':
            # Use ResNet18 as the encoder.
            resnet18 = torchvision.models.resnet18(weights='ResNet18_Weights.IMAGENET1K_V1')
            modules = list(resnet18.children())[:-1]
            resnet_enc = nn.Sequential(*modules)
            if cfg_model['cond_specs']['map_enc_freeze']:
                for p in resnet_enc.parameters():
                    p.requires_grad = False
            # Add a linear layer as a head.
            self.map_enc = nn.Sequential(
                resnet_enc,
                Rearrange('b c h w -> b (c h w)'),
                nn.Linear(512, self.n_emb_map)
            )

        else:
            raise ValueError(f"Unknown map encoder type: {map_enc_type}")

    def forward(self, map):
        # map_emb = self.map_enc(map.squeeze(-1))
        map_emb = self.map_enc(map.repeat(1, 3, 1, 1))
        return map_emb


class CondTraj(nn.Module):
    def __init__(self, cfg_data, cfg_model):
        super(CondTraj, self).__init__()
        self.n_emb_traj = cfg_model['cond_specs']['n_emb_traj']
        self.n_hist = cfg_data['n_hist']

        # self.traj_enc = nn.Sequential(
        #     # Rearrange('b l c -> b (l c)'),
        #     nn.Flatten(start_dim=1),
        #     nn.Linear(self.n_hist * 2, (self.n_emb_traj // 16) * self.n_hist),
        #     nn.GELU(),
        #     nn.Linear((self.n_emb_traj // 16) * self.n_hist, (self.n_emb_traj // 4) * self.n_hist),
        #     nn.GELU(),
        #     nn.Linear((self.n_emb_traj // 4) * self.n_hist, self.n_emb_traj * self.n_hist),
        #     Rearrange('b (l c) -> b c l', l=self.n_hist)
        # )

        layers_in = [
            Rearrange('b t c -> b c t'),
            blk(2, self.n_emb_traj // 8),
            blk(self.n_emb_traj // 8, self.n_emb_traj // 4),
            blk(self.n_emb_traj // 4, self.n_emb_traj // 2),
            nn.Conv1d(self.n_emb_traj // 2, self.n_emb_traj, 3, padding=1),
            Rearrange('b c t -> b t c'),
        ]
        self.traj_enc = nn.Sequential(*layers_in)

        # self.traj_enc = nn.Sequential(
        #     nn.Conv1d(2, self.n_emb, 1),
        #     nn.ReLU(),
        #     nn.Conv1d(self.n_emb, self.n_emb, 1),
        # )

    def forward(self, traj):
        traj_ = traj
        traj_emb = self.traj_enc(traj_)
        # traj_emb = rearrange(traj_emb, 'b (l c) -> b c l', l=self.n_hist)
        return traj_emb


class CondPose(nn.Module):
    def __init__(self, cfg_data, cfg_model):
        super(CondPose, self).__init__()
        self.n_emb_pose = cfg_model['cond_specs']['n_emb_pose']
        self.n_hist = cfg_data['n_hist']
        self.n_joints = cfg_data['n_joints']

        # self.pose_enc = nn.Sequential(
        #     Rearrange('b l c -> b (l c)'),
        #     # nn.Flatten(start_dim=1),
        #     nn.Linear(self.n_hist * 2, (self.n_emb_pose // 16) * self.n_hist),
        #     nn.GELU(),
        #     nn.Linear((self.n_emb_pose // 16) * self.n_hist, (self.n_emb_pose // 4) * self.n_hist),
        #     nn.GELU(),
        #     nn.Linear((self.n_emb_pose // 4) * self.n_hist, self.n_emb_pose * self.n_hist),
        #     Rearrange('b (l c) -> b c l', l=self.n_hist)
        # )

        layers_in = [
            Rearrange('b t j c -> b (j c) t'),
            blk((self.n_joints * 3), self.n_joints * (self.n_emb_pose // 8)),
            blk(self.n_joints * (self.n_emb_pose // 8), self.n_joints * (self.n_emb_pose // 4)),
            blk(self.n_joints * (self.n_emb_pose // 4), self.n_joints * (self.n_emb_pose // 2)),
            nn.Conv1d(self.n_joints * (self.n_emb_pose // 2), self.n_joints * (self.n_emb_pose), 3, padding=1),
            Rearrange('b c t -> b t c'),
        ]
        self.pose_enc = nn.Sequential(*layers_in)

        # self.traj_enc = nn.Sequential(
        #     nn.Conv1d(2, self.n_emb, 1),
        #     nn.ReLU(),
        #     nn.Conv1d(self.n_emb, self.n_emb, 1),
        # )

    def forward(self, pose):
        pose_emb = self.pose_enc(pose)
        # pose_emb = rearrange(pose_emb, 'b (l c) -> b c l', l=self.n_hist)
        return pose_emb


class CondModel(torch.nn.Module):

    def __init__(self, cfg_data, cfg_model):
        super(CondModel, self).__init__()

        # Setup the condition model.
        self.use_map_cond = cfg_model['cond_specs']['use_map_cond']
        self.n_emb_map = cfg_model['cond_specs']['n_emb_map']

        self.use_traj_cond = cfg_model['cond_specs']['use_traj_cond']
        self.n_emb_traj = cfg_model['cond_specs']['n_emb_traj']

        self.use_pose_cond = cfg_model['cond_specs']['use_pose_cond']
        self.n_emb_pose = cfg_model['cond_specs']['n_emb_pose']

        self.n_pred = cfg_data['n_pred']
        self.n_hist = cfg_data['n_hist']

        # ----------------- CONDITION -----------------
        self.cond_map = CondMap(cfg_data, cfg_model) if self.use_map_cond else None
        self.cond_traj = CondTraj(cfg_data, cfg_model) if self.use_traj_cond else None
        self.cond_pose = CondPose(cfg_data, cfg_model) if self.use_pose_cond else None

        self.cond_dim = 0
        if self.use_map_cond:
            self.cond_dim += self.n_emb_map
        if self.use_traj_cond:
            self.cond_dim += self.n_emb_traj
        if self.use_pose_cond:
            self.n_joints = cfg_data['n_joints']
            self.cond_dim += self.n_emb_pose * self.n_joints

        assert self.cond_dim > 0, "No condition input is provided."

        self.dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def forward(self, cond_inp):
        """
        Condition inputs. Containing the environment and pose information.
        map: (bs, 1, 64, 64, 1)
        traj: (bs, T, 2)
        pose: (bs, T, Joints, 3)
        """

        cond = torch.tensor([]).to(self.dev)
        if self.use_map_cond:
            # Map embedding.
            map = cond_inp['env']['map'].to(self.dev).float().squeeze(-1)  # (bs, 1, 64, 64, 1)->(bs, 1, 64, 64)
            map_emb = self.cond_map(map)
            # map_emb = rearrange(map_emb, 'b (c l) -> b c l', l=self.n_pred)
            map_emb = repeat(map_emb, 'b c -> b l c', l=self.n_hist)
            cond = torch.cat((cond, map_emb), dim=-1)

        # Trajectory embedding.
        if self.use_traj_cond:
            traj = cond_inp['pose']['traj'].to(self.dev).float()
            traj_emb = self.cond_traj(traj)
            cond = torch.cat((cond, traj_emb), dim=-1)

        # Pose embedding.
        if self.use_pose_cond:
            pose = cond_inp['pose']['pose'].to(self.dev).float()
            if len(pose.shape) == 3:
                pose = rearrange(pose, 'b t (j c) -> b t j c', j=self.n_joints)
            pose_emb = self.cond_pose(pose)
            cond = torch.cat((cond, pose_emb), dim=-1)

        # cond = rearrange(cond, 'b c l -> b l c')
        return cond
