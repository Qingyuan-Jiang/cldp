from copy import deepcopy

import torch

from src.models.dif_base import DiffusionBase
from src.models.dif_film import DiffusionFilm
from src.models.dif_tr import TransformerUnet
from src.models.dif_unet import ConditionalUnet1D
from src.models.predictor_base import BasePredictor

ModelCfg = {
    'mlp': DiffusionBase,
    'film': DiffusionFilm,
    'unet': ConditionalUnet1D,
    'tr': TransformerUnet,
}

class PathPred(BasePredictor):

    def __init__(self, cfg_data, cfg_model):
        super(PathPred, self).__init__(cfg_data, cfg_model)

        self.model = ModelCfg[cfg_model['model_specs']['name_specs']](cfg_data, cfg_model)

    def forward(self, poses_inp):
        # pred_info = {'pose': pose_pred, 'traj_map': traj_map_pred, 'traj': traj_raw}
        map = poses_inp['env']['map'].to(self.device).float().squeeze()
        traj = poses_inp['pose']['traj'].to(self.device).float().squeeze()

        if map.dim() == 2:
            map = map.unsqueeze(0)
            traj = traj.unsqueeze(0)

        x = torch.zeros_like(traj).to(self.device)
        t = torch.ones(traj.shape[0]).to(self.device)
        traj_pred = self.model(x, t, poses_inp)

        pred_info = {'traj': traj_pred}
        pred = {'env': poses_inp['env'], 'pose': pred_info}
        return pred

    def learn(self, inp):
        return self(inp)

    def inference(self, poses_inp, n_sample=1, **kwargs):
        # Repeat (repeat_interleave) the input for n_sample times.
        # Then, predict the output for each sample.
        # Finally, stack the outputs for each sample.
        # The output will be in the shape of bs * n_sample * np * nj * 3.
        inp = deepcopy(poses_inp)
        inp['env']['map'] = inp['env']['map'].repeat_interleave(n_sample, dim=0)
        inp['pose']['traj'] = inp['pose']['traj'].repeat_interleave(n_sample, dim=0)
        pred = self(inp)
        return pred

    def num_of_params(self):
        n = sum(p.numel() for p in self.parameters() if p.requires_grad)
        n = n / 2 ** 20  # convert to M params
        return n

    def vis_latent(self, poses_inp, n_sample=1):
        traj = poses_inp['pose']['traj'].to(self.device)
        traj_gt = poses_inp['pose']['traj_gt'].to(self.device)
        occ_map = poses_inp['env']['map'].to(self.device).float()

        cond = self.pathnet.condition(occ_map, traj)
        mu, logvar = self.pathnet.encode(traj_gt, cond)
        return mu, logvar
