from copy import deepcopy

import torch
from einops import rearrange
from torch import nn

# from src.models.dif_tr import ResBlock
from src.models.cond_model import CondModel
from src.models.dif_tr import SpatialTransformer
from src.models.predictor_base import BasePredictor


class PathNet(torch.nn.Module):
    def __init__(self, cfg_data, cfg_model):
        super(PathNet, self).__init__()
        self.cfg_data = cfg_data
        self.n_hist = cfg_data['n_hist']
        self.n_pred = cfg_data['n_pred']
        self.n_feat = cfg_model['model_specs']['n_feats']
        self.use_cvae = cfg_model['model_specs']['cvae']

        self.scene_model = CondModel(cfg_data, cfg_model)
        self.cond_dim = self.scene_model.cond_dim

        self.nblocks = 4 // 2  # Separate the number of blocks for encoder and decoder.
        self.transformer_num_heads = 8
        self.transformer_dim_head = self.n_feat
        # self.transformer_dim_head = 64
        self.transformer_depth = 1
        self.transformer_dropout = 0.1
        self.transformer_mult_ff = 2
        # self.resblock_dropout = 0.1

        # ----------------- ENCODER -----------------
        self.x_enc = nn.Sequential(
            nn.Flatten(start_dim=1),
            nn.Linear(self.n_hist * 2, self.n_hist * self.n_feat),
            nn.GELU(),
            nn.Linear(self.n_hist * self.n_feat, self.n_hist * self.n_feat),
            nn.GELU(),
            nn.Linear(self.n_hist * self.n_feat, self.n_hist * self.n_feat)
        )
        # self.x_enc = nn.Sequential(
        #     nn.Conv1d(2, self.n_feat, 1),  # (bs, 2, T) -> (bs, n_feat, T), 2 for x, y
        #     # nn.Conv1d(2, 512, 1)  # (bs, 2, T) -> (bs, n_feat, T), 2 for x, y
        # )

        # self.fc_enc1 = nn.Linear(self.n_feat * 2 + self.n_feat * 2, self.n_feat * 2)
        # self.fc_dec1 = nn.Linear(self.n_feat + self.n_feat * 2, self.n_feat * 2)

        self.enc = nn.ModuleList()
        for i in range(self.nblocks):
            # self.enc.append(
            #     ResBlock(
            #         self.n_feat,
            #         self.cond_dim * self.n_hist,
            #         self.resblock_dropout,
            #         self.n_feat,
            #     )
            # )
            self.enc.append(
                SpatialTransformer(
                    self.n_feat,
                    self.transformer_num_heads,
                    self.transformer_dim_head,
                    depth=self.transformer_depth,
                    dropout=self.transformer_dropout,
                    mult_ff=self.transformer_mult_ff,
                    context_dim=self.cond_dim,
                )
            )
        # self.fc_enc1 = nn.Linear(self.n_feat * 2, self.n_feat * 2)
        # self.fc_enc = nn.Linear(self.n_feat * 2, self.n_feat)
        self.fc_mu = nn.Sequential(
            nn.Linear(self.n_feat, self.n_feat),
            nn.ReLU(),
            nn.Linear(self.n_feat, self.n_feat)
        )
        self.fc_logvar = nn.Sequential(
            nn.Linear(self.n_feat, self.n_feat),
            nn.ReLU(),
            nn.Linear(self.n_feat, self.n_feat)
        )

        # ----------------- REPARAMETRIZATION -----------------
        self.reparametrize = lambda mu, logvar: mu + torch.randn_like(logvar) * torch.exp(logvar)

        # ----------------- DECODER -----------------
        self.dec = nn.ModuleList()
        for i in range(self.nblocks):
            # self.dec.append(
            #     ResBlock(
            #         self.n_feat,
            #         self.cond_dim * self.n_hist,
            #         self.resblock_dropout,
            #         self.n_feat,
            #     )
            # )
            self.dec.append(
                SpatialTransformer(
                    self.n_feat,
                    self.transformer_num_heads,
                    self.transformer_dim_head,
                    depth=self.transformer_depth,
                    dropout=self.transformer_dropout,
                    mult_ff=self.transformer_mult_ff,
                    context_dim=self.cond_dim,
                )
            )

        self.z_dec = nn.Linear(self.n_feat, self.n_feat)
        # self.traj_dec = nn.Sequential(
        #     nn.GroupNorm(self.n_feat // 2, self.n_feat),
        #     nn.SiLU(),
        #     nn.Conv1d(self.n_feat, 2, 1)  # (bs, 2, T) -> (bs, n_feat, T), 2 for x, y
        # )
        self.x_dec = nn.Sequential(
            nn.Flatten(start_dim=1),
            nn.Linear(self.n_pred * self.n_feat, self.n_pred * self.n_feat),
            nn.GELU(),
            nn.Linear(self.n_pred * self.n_feat, self.n_pred * self.n_feat),
            nn.GELU(),
            nn.Linear(self.n_pred * self.n_feat, self.n_pred * 2)
        )

    def encode(self, x, cond):
        """
        Encode the input trajectory x (bs, n_hist, 2) and condition.
        condition in shape (bs, n_pred, n_feat).
        """
        # h = rearrange(x, 'b l c -> b c l')
        h = x
        x_emb = self.x_enc(h)
        x_emb = rearrange(x_emb, 'b (l c) -> b c l', l=self.n_hist)

        emb = x_emb
        for i in range(self.nblocks):
            emb = self.dec[i](emb, cond)
            # cond_ = rearrange(cond, 'b l c -> b (l c)')
            # emb = self.dec[i * 2 + 0](emb, cond_)
            # emb = self.dec[i * 2 + 1](emb, cond)

        # emb_enc = F.relu(self.fc_enc1(x_emb))
        # emb_enc2 = F.relu(self.fc_enc2(emb_enc1))
        emb_enc = rearrange(emb, 'b c l -> b l c')
        mu = self.fc_mu(emb_enc)
        logvar = self.fc_logvar(emb_enc)
        return mu, logvar

    def decode(self, z, cond):
        """
        Decode from a sampled latent variable z (bs, n_pred, n_feat).
        """
        # Go through the spatial transformer blocks.
        # z = rearrange(z, 'b l c -> b c l')
        # emb = F.relu(self.z_dec(z))
        emb = rearrange(z, 'b l c -> b c l')
        for i in range(self.nblocks):
            emb = self.dec[i](emb, cond)
            # cond_ = rearrange(cond, 'b l c -> b (l c)')
            # emb = self.dec[i * 2 + 0](emb, cond_)
            # emb = self.dec[i * 2 + 1](emb, cond)
        # traj_pred = self.traj_dec(emb.squeeze(1))
        # traj_pred = rearrange(traj_pred, 'b c l -> b l c')
        traj_pred = self.x_dec(rearrange(emb, 'b c l -> b (l c)'))
        traj_pred = rearrange(traj_pred, 'b (l c) -> b l c', l=self.n_pred)
        return traj_pred

    def forward(self, x, cond_inp):
        """
        Input definition:
        map: (bs, 1, 64, 64, 1)
        traj: (bs, T, 2)
        """
        cond = self.condition(cond_inp)
        mu, logvar = self.encode(x, cond)
        z = self.reparametrize(mu, logvar) if self.use_cvae else mu
        traj_pred = self.decode(z, cond)
        return traj_pred, (mu, logvar)

    def condition(self, cond_inp):
        """
        map: (bs, 1, 64, 64, 1)
        traj: (bs, T, 2)
        """
        cond = self.scene_model(cond_inp)
        return cond


class CVAE_1d(BasePredictor):

    def __init__(self, cfg_data, cfg_model):
        super(CVAE_1d, self).__init__(cfg_data, cfg_model)
        self.model = PathNet(cfg_data, cfg_model)

    def pred_pathnet(self, traj_gt, cond_inp):
        # Predict trajectory map first and then predict pose.
        traj_pred, (mu, logvar) = self.model(traj_gt, cond_inp)
        info = {
            'mu': mu,
            'logvar': logvar
        }
        return traj_pred, info

    def forward(self, poses_inp):
        # pred_info = {'pose': pose_pred, 'traj_map': traj_map_pred, 'traj': traj_raw}
        pred_info = {}
        traj = poses_inp['pose']['traj'].to(self.device)
        traj_gt = poses_inp['pose']['traj_gt'].to(self.device)
        occ_map = poses_inp['env']['map'].to(self.device).float()

        traj_pred, info = self.pred_pathnet(traj_gt, poses_inp)
        pred_info['traj'] = traj_pred.float()
        pred_info['mu'] = info['mu']
        pred_info['logvar'] = info['logvar']
        pred = {'env': poses_inp['env'], 'pose': pred_info}
        return pred

    def learn(self, inp):
        return self(inp)

    def inference(self, poses_inp, n_sample=1, **kwargs):
        # Repeat (repeat_interleave) the input for n_sample times.
        # Then, predict the output for each sample.
        # Finally, stack the outputs for each sample.
        # The output will be in the shape of bs * n_sample * np * nj * 3.

        bs = poses_inp['pose']['traj'].shape[0]

        inp = deepcopy(poses_inp)
        inp['env']['map'] = inp['env']['map'].repeat_interleave(n_sample, dim=0)
        inp['pose']['traj'] = inp['pose']['traj'].repeat_interleave(n_sample, dim=0)
        inp['pose']['pose'] = inp['pose']['pose'].repeat_interleave(n_sample, dim=0)
        # pred = self(inp)
        z = torch.randn((bs * n_sample, self.n_pred, self.n_feat)).to(self.device)
        cond = self.model.condition(inp)
        traj_pred = self.model.decode(z, cond)
        pred = {'env': inp['env'], 'pose': {'traj': traj_pred}}
        return pred
