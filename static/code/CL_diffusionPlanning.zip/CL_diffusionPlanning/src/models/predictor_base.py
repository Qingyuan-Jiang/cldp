import torch


class BasePredictor(torch.nn.Module):

    def __init__(self, cfg_data, cfg_model):
        super(BasePredictor, self).__init__()

        self.cfg_data = cfg_data
        self.cfg_model = cfg_model

        # Dataset parameters
        self.n_hist = cfg_data['n_hist']
        self.n_pred = cfg_data['n_pred']
        self.n_joints = cfg_data['n_joints']
        self.n_feat = cfg_model['model_specs']['n_feats']
        self.map_size = cfg_data['map_size']  # Size of the map. Default 64x64
        self.d_max = cfg_data['d_max']  # Maximum distance from the current human position.
        self.resol = 2 * self.d_max / self.map_size

        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Model parameters
        self.model = None

        # Condition.
        self.use_map_cond = cfg_model['cond_specs']['use_map_cond']
        self.use_traj_cond = cfg_model['cond_specs']['use_traj_cond']
        self.use_pose_cond = cfg_model['cond_specs']['use_pose_cond']

    def forward(self, poses_inp):
        raise NotImplementedError

    def learn(self, inp):
        raise NotImplementedError

    def inference(self, poses_inp, n_sample=1, **kwargs):
        raise NotImplementedError

    def load_model(self, path):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model.load_state_dict(torch.load(path, map_location=device))

    def save_model(self, path):
        torch.save(self.model.state_dict(), path)

    def num_of_params(self):
        n = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        n = n / 2 ** 20  # convert to M params
        return n
