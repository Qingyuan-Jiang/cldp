import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange

from src.models.cond_model import CondModel
from src.models.dif_base import DiffusionBase


class SinusoidalPosEmb(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim

    def forward(self, x):
        device = x.device
        half_dim = self.dim // 2
        emb = math.log(10000) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, device=device) * -emb)
        emb = x[..., None] * emb[None, ...]
        emb = torch.cat((emb.sin(), emb.cos()), dim=-1)
        return emb


class FiLM_linear(nn.Module):
    def __init__(self, in_dim=512, cond_dim=256):
        super(FiLM_linear, self).__init__()
        # define the layers for the network
        layers = [
            nn.Linear(cond_dim, in_dim * 2),
            nn.SiLU(),
            nn.Linear(in_dim * 2, in_dim * 2),
        ]

        # create a PyTorch sequential model consisting of the defined layers
        self.model = nn.Sequential(*layers)

    def forward(self, x, cond):
        out = self.model(cond)
        gamma = out[..., :x.shape[-1]]
        beta = out[..., x.shape[-1]:]
        return gamma * x + beta


class DiffusionFilm(DiffusionBase):
    """
    This class is the implementation of the Diffusion model.
    It predicts the noise given the input trajectory and the context map.
    """

    def __init__(self, cfg_data, cfg_model):
        super(DiffusionFilm, self).__init__(cfg_data, cfg_model)

        # Setup parameters
        n_hist = cfg_data['n_hist']  # Number of history frames
        n_pred = cfg_data['n_pred']  # Number of predicted frames
        n_feat = cfg_model['model_specs']['n_feats']  # Number of features in MLP
        self.map_size = cfg_data['map_size']  # Size of the map. Default 64x64
        self.n_feat = n_feat
        self.use_traj_cond = cfg_model['model_specs']['use_traj_cond']

        # Now we construct the network
        layers = [
            nn.Flatten(start_dim=1),
            nn.Linear(n_hist * 2, n_hist * n_feat),
            nn.ReLU(),
            nn.Linear(n_hist * n_feat, n_pred * n_feat),
        ]

        self.scene_model = CondModel(cfg_data, cfg_model)
        self.cond_dim = self.scene_model.cond_dim

        self.x_emb = nn.Sequential(*layers)
        self.t_emb = nn.Sequential(
            SinusoidalPosEmb(n_hist * n_feat),
            nn.Linear(n_hist * n_feat, n_hist * n_feat),
            nn.ReLU(),
            nn.Linear(n_hist * n_feat, n_pred * n_feat),
        )

        self.fc1 = nn.Linear(n_feat * 2, n_feat * 4)
        self.fc2 = nn.Linear(n_feat * 4, n_feat * 4)
        self.fc3 = nn.Linear(n_feat * 4, n_feat * 4)
        # self.out_layer = nn.Linear(n_pred * n_feat * 4, n_pred * 2)

        # cond_dim = n_feat * 2 if self.use_traj_cond else n_feat
        self.FiLM1 = FiLM_linear(n_feat * 4, self.cond_dim)
        self.FiLM2 = FiLM_linear(n_feat * 4, self.cond_dim)
        self.FiLM3 = FiLM_linear(n_feat * 4, self.cond_dim)

        self.out = nn.Sequential(
            nn.Flatten(start_dim=1),
            nn.Linear(n_pred * n_feat * 4, n_pred * n_feat),
            nn.ReLU(),
            nn.Linear(n_pred * n_feat, n_pred * 2),
        )

    def forward(self, x, t, cond_inp):
        """
        x : (batch, n * 2) : input image
        t : (batch, n_feat)      : time step
        traj_hist : (batch, n * 2)    : context label
        """
        bs = x.shape[0]
        x = x.reshape(bs, -1)
        t = t.reshape(bs, -1)
        # traj = traj.reshape(bs, -1)
        # tjm = tjm.reshape(bs, -1)

        x_emb = self.x_emb(x)  # B, 128
        x_emb = rearrange(x_emb, 'b (l c) -> b l c', l=self.n_pred)

        t_emb = self.t_emb(t).squeeze()  # B, 128
        t_emb = rearrange(t_emb, 'b (l c) -> b l c', l=self.n_pred)

        # Condition embedding
        cond_emb = self.scene_model(cond_inp)

        x = torch.cat([
            x_emb, t_emb
        ], axis=-1)

        x1 = F.silu(self.fc1(x))
        x1 = self.FiLM1(x1, cond_emb)

        x2 = F.silu(self.fc2(x1))
        x2 = self.FiLM2(x2, cond_emb)

        x3 = F.silu(self.fc3(x2))
        x3 = self.FiLM3(x3, cond_emb)

        out = self.out(x3)
        out = rearrange(out, 'b (l c) -> b l c', l=self.n_pred)
        return out
