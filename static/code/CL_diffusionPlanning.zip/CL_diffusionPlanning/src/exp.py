"""
In this script, we conduct experiments and visualize different planner.
"""

import os
import pickle
import sys
from os.path import abspath, dirname, join

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader
from tqdm import tqdm

ROOT_DIR = abspath(join(dirname(__file__), '../'))
sys.path.append(ROOT_DIR)

from src.datasets.dataset import HumanMotionDataset
from src.utils.vis_utils import Visualizer
from src.planner.dp import DPPlanner
from src.planner.greedy import GreedyPlanner
from src.planner.oldp import OpenLoopDiffusionPlanner
from src.planner.cldp import ClosedLoopDiffusionPlanner


def cleanup(args):
    """
    In this function, we will clean up all the planning results that's from the specific planner and experiment.
    """
    # Load config.
    cfg_data_name = join(ROOT_DIR, 'src/cfg/data/%s' % args.cfg_data)
    cfg_data = yaml.safe_load(open(cfg_data_name, 'r'))
    data_name = cfg_data['dataset']

    cfg_model_name = join(ROOT_DIR, 'src/cfg/model/%s' % args.cfg_model)
    cfg_model = yaml.safe_load(open(cfg_model_name, 'r'))
    model = cfg_model['model_name']
    name_specs = cfg_model['model_specs']['name_specs']
    model_name = model + '_' + name_specs

    # cfg_plan = yaml.safe_load(open(join(ROOT_DIR, f'src/cfg/planner.yml'), 'r'))
    # latency = cfg_plan['latency']
    n_sample = args.n_sample

    exp_dir = os.path.join(ROOT_DIR, f'results/{data_name}_{model_name}_{args.exp}/')
    vis_dir = join(exp_dir, f'vis')
    if not os.path.exists(vis_dir):
        return
    for planner_name in args.planner:
        for folder in os.listdir(vis_dir):
            # Skip if it's not a folder.
            if not os.path.isdir(join(vis_dir, folder)):
                continue
            for f in os.listdir(join(vis_dir, folder)):
                if f.endswith(f'{planner_name}_{n_sample:02d}.png'):
                    os.remove(join(vis_dir, folder, f))


PLANNER_CFGS = {
    'greedy': GreedyPlanner,
    'dp': DPPlanner,
    'oldp': OpenLoopDiffusionPlanner,
    'cldp': ClosedLoopDiffusionPlanner
}


def exp_planner(args):
    # construct model
    # Load config.
    cfg_data_name = join(ROOT_DIR, 'src/cfg/data/%s' % args.cfg_data)
    cfg_data = yaml.safe_load(open(cfg_data_name, 'r'))
    data_name = cfg_data['dataset']

    cfg_model_name = join(ROOT_DIR, 'src/cfg/model/%s' % args.cfg_model)
    cfg_model = yaml.safe_load(open(cfg_model_name, 'r'))
    model = cfg_model['model_name']
    model_name = model + '_' + args.model_name

    exp_dir = os.path.join(ROOT_DIR, f'results/{data_name}_{model_name}_{args.exp}/')

    # Now load configuration from the experiment folder.
    cfg_data_name = join(exp_dir, args.cfg_data)
    cfg_data = yaml.safe_load(open(cfg_data_name, 'r'))

    cfg_model_name = join(exp_dir, args.cfg_model)
    cfg_model = yaml.safe_load(open(cfg_model_name, 'r'))

    # Load conditioning config. Merge it into the model config.
    cfg_cond_name = join(exp_dir, 'cond.yml')
    cfg_cond = yaml.safe_load(open(cfg_cond_name, 'r'))
    cfg_model.update(cfg_cond)

    # Set random seed for reproducibility.
    seed = args.seed
    torch.manual_seed(seed)
    np.random.seed(seed)

    # Setup parameters
    bs = args.batch_size

    n_pred = cfg_data['n_pred']  # Number of predicted frames
    d_max = cfg_data['d_max']
    num_workers = args.n_workers

    # Set up the planner
    planners = [PLANNER_CFGS[name](cfg_data, cfg_model, args) for name in args.planner]

    exp_dir = os.path.join(ROOT_DIR, f'results/{data_name}_{model_name}_{args.exp}/')
    res_dir = os.path.join(exp_dir, 'res')
    os.makedirs(res_dir, exist_ok=True)

    # Plan the path for each planner.
    for planner in planners:
        planner_name = planner.PLANNER_NAME
        if args.infer:
            dataset_train = HumanMotionDataset(cfg_data, cfg_model, 'train')
            # dataset_test = HumanMotionDataset(cfg_data, cfg_model, 'test')
            n_train_samp = int(0.95 * len(dataset_train))
            dataset_train, dataset_val = torch.utils.data.random_split(dataset_train, [n_train_samp, len(dataset_train) - n_train_samp])
            # dataloader_train = DataLoader(dataset_train, batch_size=bs, shuffle=True, num_workers=num_workers)
            # dataloader_test = DataLoader(dataset_val, batch_size=bs, shuffle=True, num_workers=num_workers)
            n_vis = int(0.05 * len(dataset_train))
            dataset_vis = torch.utils.data.random_split(dataset_train, [n_vis, len(dataset_train) - n_vis])[0]
            # dataloader_train = DataLoader(dataset_train, batch_size=bs, shuffle=True, num_workers=0)
            # dataloader_test = DataLoader(dataset_test, batch_size=bs, shuffle=True, num_workers=0)
            dataset_sel = dataset_vis
            dataloader_sel = DataLoader(dataset_sel, batch_size=bs, shuffle=False, num_workers=num_workers)
            inference_planner(planner, dataloader_sel, exp_dir, args)

        if args.qual:
            viser = Visualizer((-d_max, d_max, -d_max, d_max), 0.25, d_max, n_pred)
            qualitative_eval_planner(viser, planner_name, exp_dir, cfg_model, args)

        if args.quant:
            quantitative_eval_planner(planner_name, exp_dir, cfg_data, args)

    # By the end of the script, compress the experiment folder with the same name for easier download.
    if args.compress:
        vis_dir = join(exp_dir, f'vis/')
        os.system(f'zip -r {vis_dir}.zip {vis_dir}')
    return


def inference_planner(planner, dataloader, exp_dir, arg):
    # Set up the placeholders for the results.
    traj_inp_list, traj_ref_list, traj_gt_list = [], [], []
    maps_vis_list = []
    meta_list = []
    fnames, fidxs = [], []
    info_dict = {}
    path_list = []

    planner_name = planner.PLANNER_NAME
    n_sample = arg.n_sample

    # cfg_plan = yaml.safe_load(open(join(ROOT_DIR, f'src/cfg/planner.yml'), 'r'))
    # latency = cfg_plan['latency']

    res_dir = join(exp_dir, 'res')

    for (poses_inp, poses_label) in tqdm(dataloader):
        with torch.no_grad():
            # Inputs and labels.
            traj_inp = poses_inp['pose']['traj'].cpu().numpy()
            traj_gt = poses_label['pose']['traj'].cpu().numpy()

            batch_size, n_pred, _ = traj_inp.shape

            # Obtain the future human trajectory reference.
            # For the planner with a learnt prediction module, use the predicted trajectory.
            # For the naive planner, use the ground truth.
            traj_ref = planner.reference_traj(poses_inp, poses_label)

            # We are using the map for now. Uncomment this part for visualization.
            # Prepare the map.
            maps_raw = poses_inp['env']['map'].cpu().numpy().squeeze()
            maps = np.repeat(maps_raw, n_sample, axis=0)
            maps_vis = maps.reshape((batch_size, n_sample, maps_raw.shape[1], maps_raw.shape[2]))

            # Sample a robot position.
            pose = np.array([1.0, 0., 0.0])

            # i_batch, i_sample = 2, 4
            traj_ref_vis = traj_ref.reshape((batch_size, n_sample, n_pred, 2))
            # traj_ref_vis = traj_ref_vis[:, i_sample, :, :][:, None, :, :].repeat(n_sample, 1)    # Test purpose

            # Store the trajectory inputs, reference traj and ground truth.
            meta_list.append(poses_inp['env']['meta'])
            fnames += (poses_inp['env']['meta']['file'])
            fidxs += (poses_inp['env']['meta']['fidx'])
            traj_inp_list.append(traj_inp)
            traj_ref_list.append(traj_ref_vis)
            traj_gt_list.append(traj_gt)
            maps_vis_list.append(maps_vis)

            for i in range(batch_size):
                kwargs = {"traj_inp": traj_inp[i], "traj_gt": traj_gt[i]}
                path, info = planner.plan(pose, traj_ref_vis[i], maps_vis[i, 0], **kwargs)
                path_list.append(path)

        # If we are testing for one batch, we can break the loop.
        if not arg.all:
            break

    traj_inp_list = np.concatenate(traj_inp_list, axis=0)
    traj_ref_list = np.concatenate(traj_ref_list, axis=0)
    traj_gt_list = np.concatenate(traj_gt_list, axis=0)
    maps_vis_list = np.concatenate(maps_vis_list, axis=0)
    path_list = np.stack(path_list, axis=0)

    pickle_path = join(res_dir, f'results_{planner_name}_{n_sample:02d}.pkl')
    info_dict['traj_inp'] = traj_inp_list
    info_dict['traj_ref'] = traj_ref_list
    info_dict['traj_gt'] = traj_gt_list
    info_dict['maps_vis'] = maps_vis_list
    info_dict['path'] = path_list
    info_dict['meta'] = {'file': fnames, 'fidx': fidxs}
    with open(pickle_path, 'wb') as f:
        pickle.dump(info_dict, f)
    return


def qualitative_eval_planner(viser, planner_name, exp_dir, cfg_model, arg):
    # Load config.
    # cfg_plan = yaml.safe_load(open(join(ROOT_DIR, f'src/cfg/planner.yml'), 'r'))
    # latency = cfg_plan['latency']
    n_sample = arg.n_sample

    res_dir = join(exp_dir, 'res')

    # Load the results from the pickle file.
    pickle_path = join(res_dir, f'results_{planner_name}_{n_sample:02d}.pkl')
    with open(pickle_path, 'rb') as f:
        info_dict = pickle.load(f)

    # meta_list = info_dict['meta']
    fnames = info_dict['meta']['file']
    fidxs = info_dict['meta']['fidx']
    traj_inp_list = info_dict['traj_inp']
    traj_ref_list = info_dict['traj_ref']
    traj_gt_list = info_dict['traj_gt']
    path_list = info_dict['path']
    maps_vis_list = info_dict['maps_vis']

    # Visualize the trajectory inputs and predictions.
    # samples are bsx10x2. Draw them all in subplots.
    # Note that x, y should be at equal distance from the origin.

    vis_dir = join(exp_dir, f'vis/')
    n_sample = arg.n_sample
    n, n_pred, _ = traj_inp_list.shape
    traj_ref_list = traj_ref_list.reshape((n, n_sample, n_pred, 2))
    path_list = path_list.reshape((n, n_pred, 3))

    for k, (fname, fidx, traj_inp, traj_ref, traj_gt, path, maps_vis) in tqdm(enumerate(
            zip(fnames, fidxs, traj_inp_list, traj_ref_list, traj_gt_list, path_list, maps_vis_list)), mininterval=100):

        # batch_size, n_pred, _ = traj_inp.shape
        # traj_pred_vis = traj_ref.reshape((n_sample, n_pred, 2))

        # bs = traj_inp.shape[0]
        # for i in range(bs):
        seq_name = fname.split('.')[0]
        # Prepare the subfolder for the visualization.
        vis_subfolder = join(vis_dir, f'{seq_name}')
        os.makedirs(vis_subfolder, exist_ok=True)
        img_name = f'{int(fidx):04d}_{planner_name}_{n_sample:02d}.png'
        img_path = join(vis_subfolder, img_name)
        viser.vis_traj_with_occ(fname=img_path, traj_inp=traj_inp, traj_gt=traj_gt,
                                traj_ref_vis=traj_ref, path=path, occ_map=maps_vis[0])

        # If we are testing for one batch, we can break the loop.
        if not arg.all and k >= arg.batch_size:
            break

    return


def quantitative_eval_planner(planner_name, exp_dir, cfg_data, arg):
    cfg_plan = yaml.safe_load(open(join(ROOT_DIR, f'src/cfg/planner.yml'), 'r'))
    offset = cfg_plan['plan']['offset']
    penalty = cfg_plan['plan']['penalty']
    lamb_v = cfg_plan['weight']['lamb_v']
    lamb_o = cfg_plan['weight']['lamb_o']
    latency = cfg_plan['latency']
    n_sample = arg.n_sample

    n_pred = cfg_data['n_pred']
    d_max = cfg_data['d_max']

    res_dir = join(exp_dir, 'res')

    # Load the results from the pickle file.
    pickle_path = join(res_dir, f'results_{planner_name}_{n_sample:02d}.pkl')
    with open(pickle_path, 'rb') as f:
        info_dict = pickle.load(f)

    # meta_list = info_dict['meta']
    traj_inp_list = info_dict['traj_inp']
    traj_gt_list = info_dict['traj_gt']
    path_list = info_dict['path']
    maps_vis_list = info_dict['maps_vis']

    dev = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # for k, (fname, fidx, traj_inp, traj_ref, traj_gt, path, maps_vis) in tqdm(enumerate(
    #         zip(fnames, fidxs, traj_inp_list, traj_ref_list, traj_gt_list, path_list, maps_vis_list))):

    # Evaluate the planned path by the same objective.
    # 1) PPA values. 2) Collision loss.
    tau = torch.from_numpy(traj_gt_list).to(dev)
    path = torch.from_numpy(path_list).to(dev)
    vec_t2r = path[:, :, :2] - tau
    dist = torch.norm(vec_t2r, dim=-1)
    dist_shift = torch.abs(dist - offset) + offset
    # dist_shift = torch.abs(dist - offset)
    # dist_shift = dist
    # idx_dist = dist < offset

    theta = torch.atan2(tau[:, 1:, 1] - tau[:, :-1, 1], tau[:, 1:, 0] - tau[:, :-1, 0])
    theta = torch.cat((theta, theta[:, -1].unsqueeze(1)), dim=1)  # Repeat the last element. (n_sample, n_pred)
    u_tau = torch.cat((torch.cos(theta).unsqueeze(-1), torch.sin(theta).unsqueeze(-1)), dim=-1)
    u_r = torch.cat((torch.cos(path[:, :, 2]).unsqueeze(-1), torch.sin(path[:, :, 2]).unsqueeze(-1)), dim=-1)
    cos_theta = torch.sum(u_tau * u_r, dim=-1)
    cos_theta_filter = cos_theta + 1
    # cos_theta_filter = torch.max(cos_theta, torch.tensor(0.001)) + 1  # Filter out negative values.
    # 3. Calculate the PPA values.
    m_ppa = - (cos_theta_filter / dist_shift)  # Minus PPA.
    # 4. Filter out the states that the robot is behind the human.
    idx_behind = (vec_t2r * u_tau).sum(dim=-1) < 0
    # 5. Only consider the states in the field of view. (2 * 60 degree)
    vec_t2r_norm = vec_t2r / dist.unsqueeze(-1)
    idx_fov = (vec_t2r_norm * u_r).sum(-1) < np.cos(np.pi / 3)  # Only consider the states in the field of view.
    m_ppa[idx_behind] = penalty
    m_ppa[idx_fov] = penalty
    # ppa_inv[idx_dist] = penalty

    # Add the offset to make the cost positive.
    m_ppa = m_ppa + (1 + 1) / offset

    # Calculate the collision loss.

    occ = []
    for path_i, map in zip(path_list, maps_vis_list):
        map_occ = torch.abs(torch.from_numpy(map[0])).to(dev)  # (n_y, n_x)
        path_i = torch.from_numpy(path_i).to(dev)
        idx_map = torch.round((path_i[:, :2] + d_max) / (2 * d_max) * (map_occ.shape[1] - 1)).long()
        idx_map = torch.clamp(idx_map, 0, map_occ.shape[1] - 1)
        occupied = map_occ[idx_map[:, 1], idx_map[:, 0]]  # (n_pred)
        occ.append(occupied.int())
    occ = torch.stack(occ, dim=0)

    cost_map = lamb_v * m_ppa + lamb_o * occ
    cost = cost_map.mean()

    # Success rate.
    # Success is defined by the robot being in front of the human at the end of the prediction.
    succ = 1 -  idx_behind[:, -1].sum() / idx_behind.shape[0]

    # Save the results to a file
    result_path = join(res_dir, f'results_{planner_name}_{n_sample:02d}.txt')
    with open(result_path, 'w') as f:
        f.write(f'Results for {planner_name}\n')
        f.write(f'Latency = {latency}\n')
        f.write(f'N_sample = {n_sample}\n')
        f.write(f'm_ppa = {m_ppa.cpu().numpy().mean()}\n')
        f.write(f'occ = {occ.cpu().numpy().mean()}\n')
        f.write(f'cost = {cost.cpu().numpy().mean()}\n')
        f.write(f'succ = {succ.cpu().numpy()}\n')

    # Print the results by cat.
    with open(result_path, 'r') as f:
        print(f.read())


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--cfg_data', default='dummy.yml')
    parser.add_argument('--cfg_model', default='cvae.yml')
    parser.add_argument('--model_name', default='tr', type=str, help='model name')
    parser.add_argument('--mode', default='train')
    parser.add_argument('--seed', default=0, type=int)
    parser.add_argument('--n_sample', default=10, type=int)
    parser.add_argument('--epoch', default=100, type=int, help='number of total epochs to run')
    parser.add_argument('--n_workers', default=0, type=int, help='number of workers')
    parser.add_argument('--batch_size', default=2, type=int, help='batch size')
    parser.add_argument('--exp', default='1102', type=str, help='experiment name')
    parser.add_argument('--planner', '--names-list', nargs='+',
                        choices=['greedy', 'dp', 'oldp', 'cldp'], default=['cldp'],
                        help='list of planner names: \n'
                             'greedy: Pure reactive planner. \n'
                             'dp: Dynamic programming planner. \n'
                             'oldp: Open-loop diffusion planner. \n'
                             'cldp: Closed-loop diffusion planner. \n'
                        )

    parser.add_argument('--verbose', action='store_true', default=False, help='Verbose mode')
    parser.add_argument('--logs', action='store_true', default=False, help='Save intermediate results')

    parser.add_argument('--infer', action='store_true', default=False, help='Run the inference')
    parser.add_argument('--qual', action='store_true', default=False, help='Run the qualitative evaluation')
    parser.add_argument('--quant', action='store_true', default=False, help='Run the quantitative evaluation')

    parser.add_argument('--all', action='store_true', default=False, help='Run through all the test samples')
    parser.add_argument('--reset', action='store_true', default=False, help='Reset the visualization folder')

    parser.add_argument('--compress', action='store_true', default=False, help='Compress the visualization folder')
    args = parser.parse_args()

    # print the configuration.
    print("[EXP] Experiment with args: ")
    for arg in vars(args):
        print(f'[EXP] {arg}: {getattr(args, arg)}')

    # setup random seed
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    cleanup(args) if args.reset else None
    exp_planner(args)
