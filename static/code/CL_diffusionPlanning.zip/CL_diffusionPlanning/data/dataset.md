# Data structure

For each sample, the dictionary contains the following keys.

```
hist : dict_keys(['env', 'pose'])
label : dict_keys(['env', 'pose'])
```

```
hist['env']: 
    - 'pose_a_mat': 4x4 matrix of the pose of the actor.
    - 'item_key': item key of the actor.
    - 'map': local occupancy map. 40x40x1.
    - 'pcd.points': point cloud of the environment. Point Matrices. 20000x3.
    - 'pcd.colors': color of the point cloud. 20000x3.
    - 'pcd_vis.points': point cloud of the environment. Used for visualization (coud be very dense). 20000x3.
    - 'pcd_vis.colors': color of the point cloud. Used for visualization (coud be very dense). 20000x3.
```

```
hist['pose']:
    - 'pose': 3D pose of the actor. NxJx3.
    - 'pose_gt': 3D pose of the actor in the future. NxJx3.
    - 'traj_map': trajectory map of the actor. Nx40x40x1.
```
