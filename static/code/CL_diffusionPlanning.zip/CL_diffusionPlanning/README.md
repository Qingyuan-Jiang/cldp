# Closed-loop Diffusion Planning (Minimum code)

This is the code for closed-loop diffusion planning algorithms.

## To reviewers

In this repo we provide a minimum code for the reviewers to run our diffusion model to predict the human future motion,
as well as our closed-loop diffusion planning algorithm.

Because of the limited space to our supplementary material,
we can only provide the code for training and testing a model.
However, it's relatively simple and lightweight to create a dataset Junc and train/test a model locally on the Junc dataset.
We will publish our trained weight for different methods in the camera-ready version.

If you would like to test our model on the GTA-IM dataset or the HPS dataset,
you may download the raw data and preprocess it following the instructions below.
And you can run the code to train your model on the dataset.

## Dataset setup

In this project, we mainly use two datasets: GTA-IM and HPS.

- The open-sourced GTA-IM dataset can be downloaded from [here](https://github.com/ZheC/GTA-IM-Dataset).
- The HPS dataset can be downloaded from [here](https://virtualhumans.mpi-inf.mpg.de/hps/download_and_license.html).
    - You need to request access to the dataset.
    - Download the `3D scene scans` and `HPS results`

You can download the data and preprocess it using the provided code in the `src/datasets` folder.

```
cd src/datasets
python process_gta_dataset.py
python process_hps_dataset.py
```

Meanwhile, we also create a dummy dataset for Junction scenarios, which is lightweight and easy to use.
You can directly generate one locally by running the following code.

```
cd src/datasets
python process_junc_dataset.py
```

Then we separate the dataset into the training set and the testing set.
```
cd datasets
python dataset_sep.py --cfg_data junc.yml
```

The processed folder should have the following structure.

```
CL-diffusionPlanning
├── data
│   ├── GTA-IM-Dataset
│   │   ├── 2020-06-03-13-31-46
│   │   │   ├── 0000.jpg
│   ├── GTA-IM-Dataset-processed
|   |   ├── 2020-06-03-13-31-46.pcd
│   │   ├── 2020-06-03-13-31-46_sq00.hdf5
│   │   ├── ...
│   ├── Junc-Dataset-processed
│   │   ├── seq_00_sq00.hpf5
├── src
│   ├── datasets
│   ├── results -- model weights and logs
│   │   ├── gta_Path_DIF_{exp}  -- exp: 0728
│   ├── models  -- model definition
```

Now you should be able to load through the dataset. 
Test with the following code.

```
cd datasets
python dataset_gta.py --cfg_data junc.yml
```

Note that all the arguments are set in the `src/cfg/data/gta.yml`.
The dataset is loaded as a dictionary. 
Check out more information in the `data/dataset.md`.

## Usage

### Human motion prediction

To test the model with our pretrained weight, run the following command.
```bash
python src/diffusion/test.py --cfg_data junc.yml --cfg_model dif.yml --exp 0102n --batch_size 256 --epoch 200 --infer --qual --quant --reset --all
python src/diffusion/test.py --cfg_data junc.yml --cfg_model dif.yml --exp 0102n --batch_size 256 --epoch 200 --qual --all
```

To train/evaluate a model, run the following command.
```bash
python src/diffusion/train.py --cfg_data junc.yml --cfg_model dif.yml --exp 0102n --batch_size 64 --epoch 200 --n_workers 6
```
You may switch the `cfg_data` to `gta.yml` or `hps.yml` to test on the GTA-IM dataset or the HPS dataset.
You may also switch the `cfg_model` to `base.yml` or `cvae.yml` to test the diffusion model or the closed-loop diffusion planner.'

### Closed-loop Diffusion Planning

To experiment with different planning algorithm, run the following command
```bash
python src/exp.py --cfg_data junc.yml --cfg_model dif.yml --model_name tr --exp 1216s --planner cldp --epoch 300 --batch_size 64 --infer --all
python src/exp.py --cfg_data junc.yml --cfg_model dif.yml --model_name tr --exp 0102n --planner cldp --epoch 300 --batch_size 64 --qual --all
python src/exp.py --cfg_data junc.yml --cfg_model dif.yml --model_name tr --exp 0102n --planner cldp --epoch 200 --batch_size 64 --quant --all
```

You may choose other planning strategy by switching the `planner` to `greedy` or `dp` or `oldp`.
